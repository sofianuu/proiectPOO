#include "TCPServer.h"
TCPServer* TCPServer::instance = nullptr;

TCPServer* TCPServer::getInstance(short listen_port)
{
    if (TCPServer::instance == nullptr)
        TCPServer::instance = new TCPServer(listen_port);
    return TCPServer::instance;
}

TCPServer* TCPServer::getInstance()
{

    if (TCPServer::instance != nullptr)
        return TCPServer::instance;
    return nullptr;
}

void TCPServer::deleteInstance()
{
    if (TCPServer::instance != nullptr)
    {
        delete TCPServer::instance;
        TCPServer::instance = nullptr;
    }
}

TCPServer::TCPServer(short listen_port) : port(listen_port)
{

    int iResult;

    ZeroMemory(&hints, sizeof(hints));
    hints.ai_family = AF_INET;
    hints.ai_socktype = SOCK_STREAM;
    hints.ai_protocol = IPPROTO_TCP;
    hints.ai_flags = AI_PASSIVE;

    char port_str[6];
    _itoa_s(listen_port, port_str, 10);

    // Resolve the server address and port
    iResult = getaddrinfo(NULL, port_str, &hints, &result);
    if (iResult != 0) {
        printf("getaddrinfo failed with error: %d\n", iResult);
        WSACleanup();
        exit(-1);
    }

    listen_sock = socket(result->ai_family, result->ai_socktype, result->ai_protocol);
    if (listen_sock == INVALID_SOCKET) {
        printf("socket failed with error: %ld\n", WSAGetLastError());
        WSACleanup();
        exit(-1);
    }

    iResult = bind(listen_sock, result->ai_addr, (int)result->ai_addrlen);
    if (iResult == SOCKET_ERROR) {
        printf("bind failed with error: %d\n", WSAGetLastError());
        closesocket(listen_sock);
        WSACleanup();
        exit(-1);
    }

    iResult = listen(listen_sock, SOMAXCONN);
    if (iResult == SOCKET_ERROR) {
        printf("listen failed with error: %d\n", WSAGetLastError());
        closesocket(listen_sock);
        WSACleanup();
        exit(-1);
    }
}


void TCPServer::wait_connection()
{
    client_sock = accept(listen_sock, NULL, NULL);
    if (client_sock == INVALID_SOCKET) {
        printf("accept failed with error: %d\n", WSAGetLastError());
        closesocket(listen_sock);
        WSACleanup();
        exit(-1);
    }
    fprintf(stderr, "Connected\n");
    this->send("Connected!", 20);
}

int TCPServer::send(const char const* send_buff, const int size) const
{
    int send_bytes = ::send(client_sock, send_buff, size, 0);
    std::cout << "--S-au trimis informatiile catre serverul client!\n";
    std::cout << "--Informatiile trimise: "<<send_buff<<std::endl;
    return send_bytes;
}

int TCPServer::recv(char recv_buff[1024], const int size) const
{
    int recv_bytes = ::recv(client_sock, recv_buff, size, 0);
    recv_buff[recv_bytes] = '\0';
    if(strcmp(recv_buff,"primit")==0)
        return recv_bytes;
    else 
    {
        this->interpreteazaMesaj(recv_buff, recv_bytes);
        return recv_bytes;
    }
}

void TCPServer::interpreteazaMesaj(char recv_buf[1024], int size) const
{ 
    if (recv_buf[0] == '1' && recv_buf[1] == '2')
    {
        IRequest* request = CFactoryRequest::getInstance()->buildRequest(recv_buf);
        std::string result = request->executeRequest();
        this->send(result.c_str(), result.length());
        char buffer2[20];
        int bytes = this->recv(buffer2, 20);
        buffer2[bytes] = '\0';
        if (strcmp(buffer2, "primit") == 0)
           this->sendMessagesRequest();
    }
    else
    {
        if (recv_buf[0] == '1' && recv_buf[1] == '3')
        {
            IRequest* request = CFactoryRequest::getInstance()->buildRequest(recv_buf);
            std::string result = request->executeRequest();
            this->send(result.c_str(), result.length());
            char buffer2[20];
            int bytes = this->recv(buffer2, 20);
            buffer2[bytes] = '\0';
            if (strcmp(buffer2, "primit") == 0)  
              this->sendUsernames();
        }
        else
        {

            if (recv_buf[0] == '1' && recv_buf[1] == '4')
            {
                char copie[1024];
                strcpy(copie, recv_buf);
                IRequest* request = CFactoryRequest::getInstance()->buildRequest(recv_buf);
                std::string result = request->executeRequest();
                this->send(result.c_str(), result.length());
                char* username = strtok(copie, "#");
                username = strtok(NULL, "#");
                char buffer2[20];
                int bytes = this->recv(buffer2, 20);
                buffer2[bytes] = '\0';
                if (strcmp(buffer2, "primit") == 0)
                    this->sendMessagesRequest(std::string(username));
            }
            else
            {
                IRequest* request = CFactoryRequest::getInstance()->buildRequest(recv_buf);
                if (request == nullptr)
                    this->send("Optiune invalida!\n", 20);
                std::string result = request->executeRequest();
                this->send(result.c_str(), result.length());
            }
        }
    }
}

void TCPServer::getAnimalsInformationsFromDataBase() const
{
    if (DataBaseConnection::getInstance()->connectToDataBase() == true)
    {
        std::cout << "----Se preiau informatiile din baza de date despre animale!\n";
        std::wstring query = L"select A.Nume,S.Status,A.RasaID,R.Nume,A.Descriere,A.DataNastere,A.Sterilizat,A.DataSterilizarii,A.DataInregistrare,I.CaleImagine,D.CaleDescriere,F.CaleFisaMed from Animale as A inner join Imagini as I on A.ID=I.AnimalID inner join Rase as R on R.ID=A.RasaID inner join DescrieriAmanuntite as D on D.AnimalID=A.ID inner join FiseMedicale as F on F.AnimalID=A.ID inner join StatusAnimal as S on S.AnimalID=A.ID";
        if (SQL_SUCCESS != SQLExecDirect(DataBaseConnection::getInstance()->getSqlStmtHandle(), (SQLWCHAR*)query.c_str(), SQL_NTS))
        {
            std::cout << "Error querying SQL Server.\n";
            std::cout << "--Preluare esuata!\n";
            DataBaseConnection::getInstance()->disconnectDataBase();
        }
        else
        {
            SQLCHAR sqlVersion1[SQL_RESULT_LEN];
            SQLLEN ptrSqlVersion1;
            while(SQLFetch(DataBaseConnection::getInstance()->getSqlStmtHandle()) == SQL_SUCCESS)
            {
               
                std::string nume,rasaNume, descriere, dataNastere, stareSterilizare, dataSterilizare, dataInregistrare, status,caleImagine,caleFisaMedicala,caleDescriere;
                int rasaID;
                SQLGetData(DataBaseConnection::getInstance()->getSqlStmtHandle(), 1, SQL_CHAR, sqlVersion1, SQL_RESULT_LEN, &ptrSqlVersion1);
                nume = std::string((char*)sqlVersion1);
                SQLGetData(DataBaseConnection::getInstance()->getSqlStmtHandle(), 2, SQL_CHAR, sqlVersion1, SQL_RESULT_LEN, &ptrSqlVersion1);
                status = std::string((char*)sqlVersion1);
                SQLGetData(DataBaseConnection::getInstance()->getSqlStmtHandle(), 3, SQL_CHAR, sqlVersion1, SQL_RESULT_LEN, &ptrSqlVersion1);
                rasaID = atoi((char*)sqlVersion1);
                SQLGetData(DataBaseConnection::getInstance()->getSqlStmtHandle(), 4, SQL_CHAR, sqlVersion1, SQL_RESULT_LEN, &ptrSqlVersion1);
                rasaNume = std::string((char*)sqlVersion1);
                SQLGetData(DataBaseConnection::getInstance()->getSqlStmtHandle(), 5, SQL_CHAR, sqlVersion1, SQL_RESULT_LEN, &ptrSqlVersion1);
                descriere = std::string((char*)sqlVersion1);
                SQLGetData(DataBaseConnection::getInstance()->getSqlStmtHandle(), 6, SQL_CHAR, sqlVersion1, SQL_RESULT_LEN, &ptrSqlVersion1);
                dataNastere = std::string((char*)sqlVersion1);
                SQLGetData(DataBaseConnection::getInstance()->getSqlStmtHandle(), 7, SQL_CHAR, sqlVersion1, SQL_RESULT_LEN, &ptrSqlVersion1);
                stareSterilizare= std::string((char*)sqlVersion1);
                SQLGetData(DataBaseConnection::getInstance()->getSqlStmtHandle(), 8, SQL_CHAR, sqlVersion1, SQL_RESULT_LEN, &ptrSqlVersion1);
                dataSterilizare = std::string((char*)sqlVersion1);
                SQLGetData(DataBaseConnection::getInstance()->getSqlStmtHandle(), 9, SQL_CHAR, sqlVersion1, SQL_RESULT_LEN, &ptrSqlVersion1);
                dataInregistrare= std::string((char*)sqlVersion1);
                SQLGetData(DataBaseConnection::getInstance()->getSqlStmtHandle(), 10, SQL_CHAR, sqlVersion1, SQL_RESULT_LEN, &ptrSqlVersion1);
                caleImagine= std::string((char*)sqlVersion1);
                SQLGetData(DataBaseConnection::getInstance()->getSqlStmtHandle(), 11, SQL_CHAR, sqlVersion1, SQL_RESULT_LEN, &ptrSqlVersion1);
                caleDescriere = std::string((char*)sqlVersion1);
                SQLGetData(DataBaseConnection::getInstance()->getSqlStmtHandle(), 12, SQL_CHAR, sqlVersion1, SQL_RESULT_LEN, &ptrSqlVersion1);
                caleFisaMedicala = std::string((char*)sqlVersion1);
                CAnimal animal(nume,dataNastere,rasaNume,stareSterilizare,dataSterilizare,descriere,dataInregistrare,status,caleFisaMedicala,caleImagine,caleDescriere);
               const std::string informatii = animal.sendInformation();
                std::cout << "Se trimit informatiile despre animal!\n";
                this->send(informatii.c_str(), informatii.length());
                std::cout << "--Informatii preluate cu succes!\n";
                char buffer[20];
                int recv_bytes = this->recv(buffer, 20);
                buffer[recv_bytes] = '\0';
                std::cout << "-----Mesaj de la server-client: " << buffer << std::endl;
                if (strcmp(buffer,"primit") == 0)
                    continue;
                else
                    break;
            }
            DataBaseConnection::getInstance()->disconnectDataBase();
        }
    }
}

std::string TCPServer::getNrAnimals() const
{
    if (DataBaseConnection::getInstance()->connectToDataBase() == true)
    {
        if (SQL_SUCCESS != SQLExecDirect(DataBaseConnection::getInstance()->getSqlStmtHandle(), (SQLWCHAR*)L"SELECT COUNT(*) FROM Animale", SQL_NTS))
        {
            std::cout << "Error querying SQL Server.\n";
            std::cout << "--Preluare esuata!\n";
            DataBaseConnection::getInstance()->disconnectDataBase();
            return NULL;
        }
        else
        {
            SQLCHAR sqlVersion1[SQL_RESULT_LEN];
            SQLLEN ptrSqlVersion1;
            if (SQLFetch(DataBaseConnection::getInstance()->getSqlStmtHandle()) == SQL_SUCCESS)
            {
                SQLGetData(DataBaseConnection::getInstance()->getSqlStmtHandle(), 1, SQL_CHAR, sqlVersion1, SQL_RESULT_LEN, &ptrSqlVersion1);
                std::string nr = std::string((char*)sqlVersion1);
                return nr;
            }
            else
                return NULL;
        }

    }
}

void TCPServer::sendMessagesRequest() const
{

    if (DataBaseConnection::getInstance()->connectToDataBase() == true)
    {
        std::cout << "----Se preiau mesajele din baza de date!\n";
        std::string username = CUser::getInstance()->getUsername();
        std::string conversationName = "admin" + username;

        std::wstring wideConversation(conversationName.begin(), conversationName.end());
        
        std::wstring query = L"EXEC GetMessagesByConversationName @conversationName = '" + wideConversation + L"';";
        if (SQL_SUCCESS != SQLExecDirect(DataBaseConnection::getInstance()->getSqlStmtHandle(), (SQLWCHAR*)query.c_str(), SQL_NTS))
        {
            std::cout << "Error querying SQL Server.\n";
            std::cout << "--Preluare esuata!\n";
            DataBaseConnection::getInstance()->disconnectDataBase();
        }
        else
        {
            SQLCHAR sqlVersion1[SQL_RESULT_LEN];
            SQLLEN ptrSqlVersion1;
            while (SQLFetch(DataBaseConnection::getInstance()->getSqlStmtHandle()) == SQL_SUCCESS)
            {

                std::string username2, mesaj;
                SQLGetData(DataBaseConnection::getInstance()->getSqlStmtHandle(), 1, SQL_CHAR, sqlVersion1, SQL_RESULT_LEN, &ptrSqlVersion1);
                username2 = std::string((char*)sqlVersion1);
                SQLGetData(DataBaseConnection::getInstance()->getSqlStmtHandle(), 2, SQL_CHAR, sqlVersion1, SQL_RESULT_LEN, &ptrSqlVersion1);
                mesaj = std::string((char*)sqlVersion1);
                std::string buffer;
                if (username2 == username)
                    buffer = "0#" + mesaj;
                else
                    buffer = "1#" + mesaj;

                std::cout << "Se trimite mesajul!\n";

                this->send(buffer.c_str(), buffer.length());
                std::cout << "--Mesaj preluat cu succes!\n";
                char buffer2[20];
                int recv_bytes = this->recv(buffer2, 20);
                buffer2[recv_bytes] = '\0';
                std::cout << "-----Mesaj de la server-client: " << buffer2 << std::endl;
                if (strcmp(buffer2, "primit") == 0)
                    continue;
                else
                    break;
            }
            DataBaseConnection::getInstance()->disconnectDataBase();
        }
    }

}

void TCPServer::sendUsernames() const
{
    if (DataBaseConnection::getInstance()->connectToDataBase() == true)
    {
        std::cout << "----Se preiau username-rile din baza de date!\n";
        std::wstring query = L"exec GetUsernamesFromMessages";
        if (SQL_SUCCESS != SQLExecDirect(DataBaseConnection::getInstance()->getSqlStmtHandle(), (SQLWCHAR*)query.c_str(), SQL_NTS))
        {
            std::cout << "Error querying SQL Server.\n";
            std::cout << "--Preluare esuata!\n";
            DataBaseConnection::getInstance()->disconnectDataBase();
        }
        else
        {
            SQLCHAR sqlVersion1[SQL_RESULT_LEN];
            SQLLEN ptrSqlVersion1;
            while (SQLFetch(DataBaseConnection::getInstance()->getSqlStmtHandle()) == SQL_SUCCESS)
            {

                std::string username;
                SQLGetData(DataBaseConnection::getInstance()->getSqlStmtHandle(), 1, SQL_CHAR, sqlVersion1, SQL_RESULT_LEN, &ptrSqlVersion1);
                username = std::string((char*)sqlVersion1);
                if(username==CUserAdmin::getInstance()->getUsername())
                    continue;
                else
                {
           
                    std::cout << "Se trimite Username-ul!\n";
                    this->send(username.c_str(), username.length());
                    std::cout << "--Mesaj preluat cu succes!\n";
                    char buffer2[20];
                    int recv_bytes = this->recv(buffer2, 20);
                    buffer2[recv_bytes] = '\0';
                    std::cout << "-----Mesaj de la server-client: " << buffer2 << std::endl;
                    if (strcmp(buffer2, "primit") == 0)
                        continue;
                    else
                        break;
                }
            }
            DataBaseConnection::getInstance()->disconnectDataBase();
        }
    }

}

void TCPServer::sendMessagesRequest(std::string username) const
{
    if (DataBaseConnection::getInstance()->connectToDataBase() == true)
    {
        std::cout << "----Se preiau mesajele din baza de date!\n";
      //  std::string username = CUser::getInstance()->getUsername();
        std::string conversationName = "admin" + username;

        std::wstring wideConversation(conversationName.begin(), conversationName.end());

        std::wstring query = L"EXEC GetMessagesByConversationName @conversationName = '" + wideConversation + L"';";
        if (SQL_SUCCESS != SQLExecDirect(DataBaseConnection::getInstance()->getSqlStmtHandle(), (SQLWCHAR*)query.c_str(), SQL_NTS))
        {
            std::cout << "Error querying SQL Server.\n";
            std::cout << "--Preluare esuata!\n";
            DataBaseConnection::getInstance()->disconnectDataBase();
        }
        else
        {
            SQLCHAR sqlVersion1[SQL_RESULT_LEN];
            SQLLEN ptrSqlVersion1;
            while (SQLFetch(DataBaseConnection::getInstance()->getSqlStmtHandle()) == SQL_SUCCESS)
            {

                std::string username2, mesaj;
                SQLGetData(DataBaseConnection::getInstance()->getSqlStmtHandle(), 1, SQL_CHAR, sqlVersion1, SQL_RESULT_LEN, &ptrSqlVersion1);
                username2 = std::string((char*)sqlVersion1);
                SQLGetData(DataBaseConnection::getInstance()->getSqlStmtHandle(), 2, SQL_CHAR, sqlVersion1, SQL_RESULT_LEN, &ptrSqlVersion1);
                mesaj = std::string((char*)sqlVersion1);
                std::string buffer;
                if (username2 == username)
                    buffer = "0#" + mesaj;//mesaj de la client
                else
                    buffer = "1#" + mesaj;//mesaj de la admin

                std::cout << "Se trimite mesajul!\n";

                this->send(buffer.c_str(), buffer.length());
                std::cout << "--Mesaj preluat cu succes!\n";
                char buffer2[20];
                int recv_bytes = this->recv(buffer2, 20);
                buffer2[recv_bytes] = '\0';
                std::cout << "-----Mesaj de la server-client: " << buffer2 << std::endl;
                if (strcmp(buffer2, "primit") == 0)
                    continue;
                else
                    break;
            }
            DataBaseConnection::getInstance()->disconnectDataBase();
        }
    }

}

