#include "CLogUserRequest.h"

std::string CLogUserRequest::executeRequest()
{
    char* username = strtok(this->request, "#");
    username = strtok(NULL, "#");
    char* parola = strtok(NULL, "#");
    const char* ans = CUser::getInstance(std::string(username), std::string(parola))->authentificateUser();
    std::string buffer = std::string(ans);
    if (strcmp(ans, "0") == 0)
    {
        CUser::deleteInstance();
    }

    if (strcmp(ans, "1") == 0)
    {
       buffer =buffer+"#"+ CUser::getInstance()->sendInformation();
    }
    return buffer;
   
}
