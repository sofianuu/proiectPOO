#pragma once
#include <string>


int sock_init();
char* cut(char* sir, char delimit);

