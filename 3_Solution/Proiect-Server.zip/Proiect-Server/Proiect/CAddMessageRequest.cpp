#include "CAddMessageRequest.h"

std::string CAddMessageRequest::executeRequest()
{
    char* mesaj = strtok(this->request, "#");
    mesaj = strtok(NULL, "#");
    if (CUserAdmin::getInstance() != nullptr)
    {
        char* usernameClient = strtok(NULL, "#");
        return  CUserAdmin::getInstance()->addMessage(mesaj, usernameClient);
    }
    else
       return CUser::getInstance()->addMessage(mesaj);
}
