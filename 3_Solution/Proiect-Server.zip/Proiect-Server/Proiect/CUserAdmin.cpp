#include "CUserAdmin.h"
CUserAdmin* CUserAdmin::instance = nullptr;

CUserAdmin* CUserAdmin::getInstance(std::string nume, std::string prenume, std::string adresa, std::string nrTelefon, std::string dataNastere, std::string email, std::string gen)
{
	if (CUserAdmin::instance == nullptr)
	{
		CUserAdmin::instance = new CUserAdmin(nume, prenume, adresa, nrTelefon, dataNastere, email, gen);
    }
	return CUserAdmin::instance;
}

CUserAdmin* CUserAdmin::getInstance(std::string username, std::string passw)
{
	if (CUserAdmin::instance == nullptr)
	{
		CUserAdmin::instance = new CUserAdmin(username,passw);
	}
	return CUserAdmin::instance;
}

void CUserAdmin::deleteInstance()
{
	if (CUserAdmin::instance != nullptr)
	{
        delete CUserAdmin::instance;
		CUserAdmin::instance = nullptr;
	}
}

CUserAdmin* CUserAdmin::getInstance()
{
    if (CUserAdmin::instance == nullptr)
    {
        std::cout << "Actiune nepermisa!";
    }
    return CUserAdmin::instance;
}

const char* CUserAdmin::addAnimal(const CAnimal& animal)
{
    if (DataBaseConnection::getInstance()->connectToDataBase() == true)
    {
        std::cout << "----Se adauga animal nou in baza de date!\n";
        
        std::string descriere = animal.getDescriere();
        std::string nume = animal.getNume();
        std::string dataNastere = animal.getDataNastere();
        std::string sterilizat = animal.getSterilizare();
        std::string dataSterilizare = animal.getDataSterilizare();
        std::string rasa = animal.getRasa();
    
  
        std::wstring wideDescriere(descriere.begin(), descriere.end());
        std::wstring wideNume(nume.begin(), nume.end());
        std::wstring wideDataNastere(dataNastere.begin(), dataNastere.end());
        std::wstring wideSterilizat(sterilizat.begin(),sterilizat.end());
        std::wstring wideDataSterilizare(dataSterilizare.begin(), dataSterilizare.end());
        std::wstring wideRasa(rasa.begin(), rasa.end());
        std::wstring query;

        if(sterilizat=="nu" || sterilizat=="Nu")
           query = L"EXEC AddAnimalByBreedName @Nume = '" + wideNume + L"', @RasaNume = '" + wideRasa + L"', @DataNastere = '" + wideDataNastere + L"',@Sterilizat = '" + wideSterilizat + L"',@DataSterilizarii = " + wideDataSterilizare + L", @Descriere = '" + wideDescriere + L"';";
        else
            query = L"INSERT INTO Animale(Nume,RasaID,DataNastere,DataInregistrare,DataSterilizarii,Sterilizat,Descriere)SELECT '" + wideNume + L"', ID ,'" + wideDataNastere + L"',GETDATE(),'" + wideDataSterilizare + L"','" + wideSterilizat + L"','" + wideDescriere + L"' FROM Rase WHERE Nume = '" + wideRasa + L"')";

        if (SQL_SUCCESS != SQLExecDirect(DataBaseConnection::getInstance()->getSqlStmtHandle(), (SQLWCHAR*)query.c_str(), SQL_NTS))
        {
            std::cout << "Error querying SQL Server.\n";
            std::cout << "--Adaugare animal esuata!\n";
            DataBaseConnection::getInstance()->disconnectDataBase();
            return "0";
        }
        else
        {
            std::cout << "--Animal adaugat cu succes!\n";
            DataBaseConnection::getInstance()->disconnectDataBase();
            return "1";
        }
    }
    else
        return "0";
 
}


const char* CUserAdmin::authentificateAdmin()
{

    if (DataBaseConnection::getInstance()->connectToDataBase() == true)
    {
        if (SQL_SUCCESS != SQLExecDirect(DataBaseConnection::getInstance()->getSqlStmtHandle(), (SQLWCHAR*)L"SELECT Username, Parola FROM Utilizatori INNER JOIN Administratori ON Utilizatori.ID = Administratori.UtilizatorID", SQL_NTS))
        {
            std::cout << "Error querying SQL Server.\n";
            DataBaseConnection::getInstance()->disconnectDataBase();
            return "2";
        }
        else
        {
            SQLCHAR sqlVersion1[SQL_RESULT_LEN];
            SQLLEN ptrSqlVersion1;
            SQLCHAR sqlVersion2[SQL_RESULT_LEN];
            SQLLEN ptrSqlVersion2;
            while (SQLFetch(DataBaseConnection::getInstance()->getSqlStmtHandle()) == SQL_SUCCESS)
            {
                SQLGetData(DataBaseConnection::getInstance()->getSqlStmtHandle(), 1, SQL_CHAR, sqlVersion1, SQL_RESULT_LEN, &ptrSqlVersion1);
                SQLGetData(DataBaseConnection::getInstance()->getSqlStmtHandle(), 2, SQL_CHAR, sqlVersion2, SQL_RESULT_LEN, &ptrSqlVersion1);
                if (this->Username == std::string((char*)sqlVersion1) && this->Parola == std::string((char*)sqlVersion2))
                {
                    std::cout << "----Administrator existent!\n";
                    DataBaseConnection::getInstance()->disconnectDataBase();
                    return "1";
                }
                else
                    if (this->Username == std::string((char*)sqlVersion1) && this->Parola != std::string((char*)sqlVersion2))
                    {
                        std::cout << "----Parola administrator gresita!\n";
                        DataBaseConnection::getInstance()->disconnectDataBase();
                        return "0";

                    }

            }
            DataBaseConnection::getInstance()->disconnectDataBase();
            std::cout << "----Utilizatorul nu se poate conecta ca administrator!\n";
            return "2";
        }
    }
    else
        return "2";
}

const char* CUserAdmin::addOtherAnimalInformations(const CAnimal& animal)
{
    std::string ID;
    if (DataBaseConnection::getInstance()->connectToDataBase() == true)
    {
        if (SQL_SUCCESS != SQLExecDirect(DataBaseConnection::getInstance()->getSqlStmtHandle(), (SQLWCHAR*)L"SELECT TOP 1 ID FROM Animale ORDER BY ID DESC", SQL_NTS))
        {
            std::cout << "Error querying SQL Server.\n";
            std::cout << "--Preluare ID esuata!\n";
            DataBaseConnection::getInstance()->disconnectDataBase();
            return "0";
        }
        else
        {
            if (SQLFetch(DataBaseConnection::getInstance()->getSqlStmtHandle()) == SQL_SUCCESS)
            {
                SQLCHAR sqlVersion1[SQL_RESULT_LEN];
                SQLLEN ptrSqlVersion1;
                SQLGetData(DataBaseConnection::getInstance()->getSqlStmtHandle(), 1, SQL_CHAR, sqlVersion1, SQL_RESULT_LEN, &ptrSqlVersion1);
                ID = std::string((char*)sqlVersion1);
                DataBaseConnection::getInstance()->disconnectDataBase();
            }
        }
    }
    else
    {
        return "0";
    }
    std::wstring wideID(ID.begin(), ID.end());
    if (DataBaseConnection::getInstance()->connectToDataBase() == true)
    {
        std::string caleImagine = animal.getCaleImagine();
        std::string caleDescriere = animal.getCaleDescriere();
        std::string caleFisaMed = animal.getCaleFisaMed();
        std::string status = animal.getStatus();

        std::wstring wideCaleImagine(caleImagine.begin(), caleImagine.end());
        std::wstring wideCaleDescriere(caleDescriere.begin(), caleDescriere.end());
        std::wstring wideCaleFisaMed(caleFisaMed.begin(), caleFisaMed.end());
        std::wstring wideStatus(status.begin(), status.end());
        std::wstring query = L"INSERT INTO Imagini(AnimalID,CaleImagine) VALUES ('" + wideID + L"', '" + wideCaleImagine + L"' );INSERT INTO DescrieriAmanuntite (AnimalID,CaleDescriere) VALUES ('" + wideID + L"', '" + wideCaleDescriere + L"');INSERT INTO FiseMedicale(AnimalID,CaleFisaMed) VALUES ('" + wideID + L"', '" + wideCaleFisaMed + L"');INSERT INTO StatusAnimal (AnimalID,Status,DataActualizareStatus) VALUES ('" + wideID + L"', '" + wideStatus + L"', GETDATE())";
        if (SQL_SUCCESS != SQLExecDirect(DataBaseConnection::getInstance()->getSqlStmtHandle(), (SQLWCHAR*)query.c_str(), SQL_NTS))
        {
            std::cout << "Error querying SQL Server.\n";
            std::cout << "--Inserare documente animal esuata!\n";
            DataBaseConnection::getInstance()->disconnectDataBase();
            return "0";
        }
        else
        {
            std::cout << "--Inserare documente animal reusita!\n";
            DataBaseConnection::getInstance()->disconnectDataBase();
            return "1";
        }
    }
    else
        return "0";
}

const char* CUserAdmin::aproveOrDenyAdoptionRequest(std::string caleFormularAdoptie, std::string Status)
{
    if (DataBaseConnection::getInstance()->connectToDataBase() == true)
    {
        std::cout << "--Se actualizeaza statusul cererii de adoptie!\n";

        std::wstring wideCaleFormularAdoptie(caleFormularAdoptie.begin(), caleFormularAdoptie.end());
        std::wstring wideStatus(Status.begin(), Status.end());

        std::wstring query = L"EXEC AprobaSauRespingeCerereAdoptie '" + wideCaleFormularAdoptie + L"', '" + wideStatus + L"'";
        if (SQL_SUCCESS != SQLExecDirect(DataBaseConnection::getInstance()->getSqlStmtHandle(), (SQLWCHAR*)query.c_str(), SQL_NTS))
        {
            std::cout << "Error querying SQL Server.\n";
            std::cout << "--Status cerere de adoptie neactualizat!\n";
            DataBaseConnection::getInstance()->disconnectDataBase();
            return "0";
        }
        else
        {
            std::cout << "--Status cerere de adoptie actualizat cu succes!\n";
        }
        DataBaseConnection::getInstance()->disconnectDataBase();
        return "1";

    }
    else
        return "0";
}

const char* CUserAdmin::addMessage(std::string mesaj, std::string usernameClient)
{
    if (DataBaseConnection::getInstance()->connectToDataBase() == true)
    {
        std::cout << "--Se inregistreaza mesajul trimis de utilizatorul cu username-ul " << this->Username << " .\n";

        std::string numeConversatie = "admin" + usernameClient;
        std::wstring wideUsername(this->Username.begin(), this->Username.end());
        std::wstring wideMesaj(mesaj.begin(), mesaj.end());
        std::wstring wideNumeConversatie(numeConversatie.begin(), numeConversatie.end());
        std::wstring query = L"EXEC AdaugaConversatieSiMesaj2 @NumeConversatie= '" + wideNumeConversatie + L"',  @Username= '" + wideUsername + L"', @MesajText= '" + wideMesaj + L"'";
        if (SQL_SUCCESS != SQLExecDirect(DataBaseConnection::getInstance()->getSqlStmtHandle(), (SQLWCHAR*)query.c_str(), SQL_NTS))
        {
            std::cout << "Error querying SQL Server.\n";
            std::cout << "--Inregistrare mesaj esuata!\n";
            DataBaseConnection::getInstance()->disconnectDataBase();
            return "0";
        }
        else
        {
            std::cout << "--Mesajul s-a inregistrat cu succes!\n";
        }
        DataBaseConnection::getInstance()->disconnectDataBase();
        return "1";

    }
    else
        return "0";
}
