#pragma once
#include "CUserAdmin.h"

class IRequest
{
public:
	virtual	std::string executeRequest() = 0;
};

