#undef UNICODE

#define WIN32_LEAN_AND_MEAN
#define _CRT_SECURE_NO_WARNINGS

#include <windows.h>
#include <winsock2.h>
#include <ws2tcpip.h>
#include <stdlib.h>
#include <stdio.h>
#include "Utils.h"

int sock_init() {
    WSADATA wsaData;
    int iResult;

    // Initialize Winsock
    iResult = WSAStartup(MAKEWORD(2, 2), &wsaData);
    if (iResult != 0) {
        printf("WSAStartup failed with error: %d\n", iResult);
        return -1;
    }

    return 0;
}

char* cut(char* sir, char delimit)
{
    char* ptr = strchr(sir,delimit);
    if (ptr != NULL)
    {
        *ptr = '\0';
        ptr++;
    }
    char cuv[20];
    strcpy(cuv, sir);
    if(ptr!=NULL)
      strcpy(sir,ptr);

    return cuv;
}
