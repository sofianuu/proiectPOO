#pragma once
#include "CUser.h"
#include "CAnimal.h"

class CUserAdmin :public CUser
{
private:
	static CUserAdmin* instance;
	CUserAdmin(std::string nume, std::string prenume, std::string adresa, std::string nrTelefon, std::string dataNastere, std::string email, std::string gen) :CUser(nume, prenume, adresa, nrTelefon, dataNastere, email, gen) {};
	CUserAdmin(const CUserAdmin&) {};
	CUserAdmin() :CUser() {};
	CUserAdmin(std::string username, std::string passw) :CUser(username, passw) {};
	~CUserAdmin() {};
public:
	static CUserAdmin* getInstance(std::string nume, std::string prenume, std::string adresa, std::string nrTelefon, std::string dataNastere, std::string email, std::string gen);
	static CUserAdmin* getInstance(std::string username, std::string passw);
	static void deleteInstance();
	static CUserAdmin* getInstance();
	
	//alte functii doar pt administrator
	const char* addAnimal(const CAnimal& animal) override;
	const char* authentificateAdmin()override;
	const char* addOtherAnimalInformations(const CAnimal& animal)override;
	const char* aproveOrDenyAdoptionRequest(std::string caleFormularAdoptie, std::string Status)override;
	const char* addMessage(std::string mesaj, std::string usernameClient) override;
};

