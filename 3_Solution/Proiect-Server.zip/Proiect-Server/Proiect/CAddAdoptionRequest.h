#pragma once
#include "ARequest.h"
class CAddAdoptionRequest :public ARequest
{
public:
	CAddAdoptionRequest(char request[1024]) :ARequest(request) {};
	CAddAdoptionRequest() {};
	std::string executeRequest()override;
};

