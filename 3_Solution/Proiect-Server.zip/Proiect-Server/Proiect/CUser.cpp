#include "CUser.h"
CUser* CUser::instance = nullptr;

CUser::~CUser()
{
 
}

CUser* CUser::getInstance(std::string nume, std::string prenume, std::string adresa, std::string nrTelefon, std::string dataNastere, std::string email, std::string gen)
{
	if (CUser::instance == nullptr)
		CUser::instance = new CUser(nume,prenume,adresa,nrTelefon,dataNastere,email,gen);
	return CUser::instance;
}

void CUser::deleteInstance()
{
	if (CUser::instance != nullptr)
	{
		delete CUser::instance;
        std::cout << "Utilizator sters cu succes!\n";
		CUser::instance = nullptr;
	}
}

CUser* CUser::getInstance()
{
	if (CUser::instance == nullptr)
	{
		std::cout << "Actiune nepermisa!";
	}
	return CUser::instance;
}

CUser* CUser::getInstance(std::string username, std::string passw)
{
	if (CUser::instance == nullptr)
		CUser::instance = new CUser(username,passw);
	return CUser::instance;
}

const char * CUser::registerUser()
{
    DataBaseConnection::getInstance()->connectToDataBase();
    std::cout << "Se inregistreaza utilizator...\n";
    std::wstring numeWide(this->Nume.begin(), this->Nume.end());
    std::wstring prenumeWide(this->Prenume.begin(), this->Prenume.end());
    std::wstring emailWide(this->Email.begin(), this->Email.end());
    std::wstring parolaWide(this->Parola.begin(), this->Parola.end());
    std::wstring genWide(this->Gen.begin(), this->Gen.end());
    std::wstring DataNastereWide(this->DataNastere.begin(), this->DataNastere.end());
    std::wstring nrTelefonWide(this->NrTelefon.begin(), this->NrTelefon.end());
    std::wstring adresaWide(this->Adresa.begin(), this->Adresa.end());
    std::wstring usernameWide(this->Username.begin(), this->Username.end());
    std::wstring query = L"INSERT INTO Utilizatori VALUES('" + numeWide + L"', '" + prenumeWide + L"', '" + emailWide + L"', '" + parolaWide + L"',GETDATE(),'" + genWide + L"', '" + DataNastereWide + L"', '" + nrTelefonWide + L"', '" + adresaWide + L"', '" + usernameWide + L"')";
    if (SQL_SUCCESS != SQLExecDirect(DataBaseConnection::getInstance()->getSqlStmtHandle(), (SQLWCHAR*)query.c_str(), SQL_NTS))
    {
        std::cout << "Error querying SQL Server.\n";
        std::cout << "Inregistrare esuata!\n";
        DataBaseConnection::getInstance()->disconnectDataBase();
        return "0";
    }
    else
    {
        std::cout << "Utilizator nou adaugat in baza de date!\n";
    }
    DataBaseConnection::getInstance()->disconnectDataBase();
    return "1";
}

void CUser::setPassword(std::string passw)
{
	this->Parola = passw;
}

void CUser::setUsername(std::string username)
{
	this->Username = username;
}

const char* CUser::authentificateUser()
{
    std::cout << "Se autentifica utilizatorul...\n";
    DataBaseConnection::getInstance()->connectToDataBase();
    if (SQL_SUCCESS != SQLExecDirect(DataBaseConnection::getInstance()->getSqlStmtHandle(), (SQLWCHAR*)L"SELECT Username,Parola FROM Utilizatori", SQL_NTS))
    {
        std::cout << "Error querying SQL Server.\n";
        DataBaseConnection::getInstance()->disconnectDataBase();
        return "0";
    }
    else
    {
        SQLCHAR sqlVersion1[SQL_RESULT_LEN];
        SQLLEN ptrSqlVersion1;
        SQLCHAR sqlVersion2[SQL_RESULT_LEN];
        SQLLEN ptrSqlVersion2;
        bool ok = 0;
        while (SQLFetch(DataBaseConnection::getInstance()->getSqlStmtHandle()) == SQL_SUCCESS)
        {
            SQLGetData(DataBaseConnection::getInstance()->getSqlStmtHandle(), 1, SQL_CHAR, sqlVersion1, SQL_RESULT_LEN, &ptrSqlVersion1);
            SQLGetData(DataBaseConnection::getInstance()->getSqlStmtHandle(), 2, SQL_CHAR, sqlVersion2, SQL_RESULT_LEN, &ptrSqlVersion2);

            if (strcmp(this->Username.c_str(), (char*)sqlVersion1) == 0 && strcmp(this->Parola.c_str(), (char*)sqlVersion2) == 0)
            {
                std::cout << "Utilizator existent!\n";
                DataBaseConnection::getInstance()->disconnectDataBase();
                return "1";
                break;
            }
        }

    }
    std::cout << "Utilizator inexistent!\n";
   DataBaseConnection::getInstance()->disconnectDataBase();
   return "0";
}

const char* CUser::checkUsername(std::string username)
{
    DataBaseConnection::getInstance()->connectToDataBase();
    std::cout << "Se verifica username-ul...\n";
    if (SQL_SUCCESS != SQLExecDirect(DataBaseConnection::getInstance()->getSqlStmtHandle(), (SQLWCHAR*)L"SELECT Username FROM Utilizatori", SQL_NTS))
    {
        std::cout << "Error querying SQL Server.\n";
        std::cout << "Verificare esuata!\n";
        DataBaseConnection::getInstance()->disconnectDataBase();
    }
    else
    {
        SQLCHAR sqlVersion1[SQL_RESULT_LEN];
        SQLLEN ptrSqlVersion1;
        while (SQLFetch(DataBaseConnection::getInstance()->getSqlStmtHandle()) == SQL_SUCCESS)
        {
            SQLGetData(DataBaseConnection::getInstance()->getSqlStmtHandle(), 1, SQL_CHAR, sqlVersion1, SQL_RESULT_LEN, &ptrSqlVersion1);
            if (strcmp(username.c_str(), (char*)sqlVersion1) == 0)
            {
                DataBaseConnection::getInstance()->disconnectDataBase();
                std::cout << "Username existent in sistem!\n";
                return "0";
                break;
            }
        }
        DataBaseConnection::getInstance()->disconnectDataBase();
        std::cout << "Username unic in sistem!\n";
        return "1";
    }
}

std::string CUser::sendInformation()
{
    this->getInformationFromDataBase();
    std::cout << "----Se pregatesc informatiile!\n";
    std::string buffer = this->Nume + "#" + this->Prenume + "#" + this->Email + "#" + this->Gen + "#" + this->DataNastere + "#" + this->NrTelefon + "#" + this->Adresa;
    return buffer;
}

void CUser::getInformationFromDataBase()
{
    if (DataBaseConnection::getInstance()->connectToDataBase() == true)
    {
        std::cout << "----Se preiau informatiile din baza de date despre utilizator!\n";
        std::wstring wideUsername(this->Username.begin(), this->Username.end());
        std::wstring query = L"SELECT Nume,Prenume,Email,DataInregistrare,Gen,DataNasterii,NrTelefon,Adresa FROM Utilizatori WHERE Username= '" + wideUsername + L"'";
        if (SQL_SUCCESS != SQLExecDirect(DataBaseConnection::getInstance()->getSqlStmtHandle(), (SQLWCHAR*)query.c_str(), SQL_NTS))
        {
            std::cout << "Error querying SQL Server.\n";
            std::cout << "--Preluare esuata!\n";
            DataBaseConnection::getInstance()->disconnectDataBase();
        }
        else
        {
            SQLCHAR sqlVersion1[SQL_RESULT_LEN];
            SQLLEN ptrSqlVersion1;
           /* SQLCHAR sqlVersion1[SQL_RESULT_LEN];
            SQLCHAR sqlVersion1[SQL_RESULT_LEN];
            SQLCHAR sqlVersion1[SQL_RESULT_LEN];
            SQLCHAR sqlVersion1[SQL_RESULT_LEN];
            SQLCHAR sqlVersion1[SQL_RESULT_LEN];
            SQLCHAR sqlVersion1[SQL_RESULT_LEN];
            SQLLEN ptrSqlVersion1;
            SQLLEN ptrSqlVersion2;
            SQLLEN ptrSqlVersion3;
            SQLLEN ptrSqlVersion4;
            SQLLEN ptrSqlVersion5;
            SQLLEN ptrSqlVersion6;
            SQLLEN ptrSqlVersion7;
            SQLLEN ptrSqlVersion8;*/
            if (SQLFetch(DataBaseConnection::getInstance()->getSqlStmtHandle()) == SQL_SUCCESS)
            {
                SQLGetData(DataBaseConnection::getInstance()->getSqlStmtHandle(), 1, SQL_CHAR, sqlVersion1, SQL_RESULT_LEN, &ptrSqlVersion1);
                this->Nume = std::string((char*)sqlVersion1);
                SQLGetData(DataBaseConnection::getInstance()->getSqlStmtHandle(), 2, SQL_CHAR, sqlVersion1, SQL_RESULT_LEN, &ptrSqlVersion1);
                this->Prenume = std::string((char*)sqlVersion1);
                SQLGetData(DataBaseConnection::getInstance()->getSqlStmtHandle(), 3, SQL_CHAR, sqlVersion1, SQL_RESULT_LEN, &ptrSqlVersion1);
                this->Email = std::string((char*)sqlVersion1);
                SQLGetData(DataBaseConnection::getInstance()->getSqlStmtHandle(), 4, SQL_CHAR, sqlVersion1, SQL_RESULT_LEN, &ptrSqlVersion1);
                this->DataInregistrare = std::string((char*)sqlVersion1);
                SQLGetData(DataBaseConnection::getInstance()->getSqlStmtHandle(), 5, SQL_CHAR, sqlVersion1, SQL_RESULT_LEN, &ptrSqlVersion1);
                this->Gen = std::string((char*)sqlVersion1);
                SQLGetData(DataBaseConnection::getInstance()->getSqlStmtHandle(), 6, SQL_CHAR, sqlVersion1, SQL_RESULT_LEN, &ptrSqlVersion1);
                this->DataNastere = std::string((char*)sqlVersion1);
                SQLGetData(DataBaseConnection::getInstance()->getSqlStmtHandle(), 7, SQL_CHAR, sqlVersion1, SQL_RESULT_LEN, &ptrSqlVersion1);
                this->NrTelefon = std::string((char*)sqlVersion1);
                SQLGetData(DataBaseConnection::getInstance()->getSqlStmtHandle(), 8, SQL_CHAR, sqlVersion1, SQL_RESULT_LEN, &ptrSqlVersion1);
                this->Adresa = std::string((char*)sqlVersion1);
                std::cout << "--Informatii preluate cu succes!\n";
            }
            DataBaseConnection::getInstance()->disconnectDataBase();
        }
    }
}

const char* CUser::updateInformations(std::string newNume, std::string newPrenume, std::string newAdress, std::string newMail, std::string newPassw, std::string newPhone, std::string newUsername)
{
    if (DataBaseConnection::getInstance()->connectToDataBase() == true)
    {
        std::cout << "Se actualizeaza informatiile utilizatorului cu username-ul " << this->Username << "...\n";
        DataBaseConnection::getInstance()->connectToDataBase();
        std::wstring usernameWide(this->Username.begin(), this->Username.end());
        std::wstring newNumeWide(newNume.begin(), newNume.end());
        std::wstring newPrenumeWide(newPrenume.begin(), newPrenume.end());
        std::wstring newAdressWide(newAdress.begin(), newAdress.end());
        std::wstring newMailWide(newMail.begin(), newMail.end());
        std::wstring newPasswWide(newPassw.begin(), newPassw.end());
        std::wstring newPhoneWide(newPhone.begin(), newPhone.end());
        std::wstring newUsernameWide(newUsername.begin(), newUsername.end());
        std::wstring query = L"UPDATE Utilizatori SET Username = '" + newUsernameWide + L"', Prenume = '" + newPrenumeWide + L"', Adresa =  '" + newAdressWide + L"', Email =  '" + newMailWide + L"', Parola =  '" + newPasswWide + L"', NrTelefon =  '" + newPhoneWide + L"', Nume =  '" + newNumeWide + L"' WHERE Username = '" + usernameWide + L"'";
        if (SQL_SUCCESS != SQLExecDirect(DataBaseConnection::getInstance()->getSqlStmtHandle(), (SQLWCHAR*)query.c_str(), SQL_NTS))
        {
            std::cout << "Error querying SQL Server.\n";
            std::cout << "Actualizare informatii utilizatori esuata!\n";
            DataBaseConnection::getInstance()->disconnectDataBase();
            return "0";
        }
        else
        {
            std::cout << "Informatii actualizate cu succes!\n";
        }
        DataBaseConnection::getInstance()->disconnectDataBase();
        return "1";
    }
    else
        return "0";
}

const char* CUser::addDonation(std::string suma)
{
    if (DataBaseConnection::getInstance()->connectToDataBase() == true)
    {
      
        std::cout << "--Se inregistreaza donatia in valoare de " << suma << " facuta de catre utilizatorul "<< this->Username<<"." << std::endl;

        std::string username= this->Username;

        std::wstring wideUsername(username.begin(), username.end());
        std::wstring wideSuma(suma.begin(), suma.end());
        std::wstring query = L"exec AddDonationByUsername2 @username = '" + wideUsername + L"', @suma = " + wideSuma + L";";
        if (SQL_SUCCESS != SQLExecDirect(DataBaseConnection::getInstance()->getSqlStmtHandle(), (SQLWCHAR*)query.c_str(), SQL_NTS))
        {
            std::cout << "Error querying SQL Server.\n";
            std::cout << "--Inregistrare donatie esuata!\n";
            DataBaseConnection::getInstance()->disconnectDataBase();
            return "0";
        }
        else
        {
            std::cout << "--Inregistrare donatie cu succes!\n";
        }
        DataBaseConnection::getInstance()->disconnectDataBase();
        return "1";
    }
    else
     return "0";
}

const char* CUser::addAdoptionRequest(std::string numeAnimal,std::string caleFormularAdoptie)
{
    if (DataBaseConnection::getInstance()->connectToDataBase() == true)
    {
        std::cout << "--Se inregistreaza cererea de adoptie!\n";

        std::string username = this->Username;

        std::wstring wideCaleFormularAdoptie(caleFormularAdoptie.begin(), caleFormularAdoptie.end());
        std::wstring wideUsername(username.begin(), username.end());
        std::wstring wideNumeAnimal(numeAnimal.begin(), numeAnimal.end());
        std::wstring query = L"EXEC AddAdoptionRequestByUsernameAndAnimalName2 @username='" + wideUsername + L"', @animalName='" + wideNumeAnimal + L"', @caleFormularAdoptie= '" + wideCaleFormularAdoptie + L"'";
        if (SQL_SUCCESS != SQLExecDirect(DataBaseConnection::getInstance()->getSqlStmtHandle(), (SQLWCHAR*)query.c_str(), SQL_NTS))
        {
            std::cout << "Error querying SQL Server.\n";
            std::cout << "--Inregistrare cerere de adoptie esuata!\n";
            DataBaseConnection::getInstance()->disconnectDataBase();
            return "0";
        }
        else
        {
            std::cout << "--Inregistrare cerere de adoptie cu succes!\n";
        }
        DataBaseConnection::getInstance()->disconnectDataBase();
        return "1";

    }
    else
        return "0";
}

const char* CUser::addMessage(std::string mesaj)
{
    if (DataBaseConnection::getInstance()->connectToDataBase() == true)
    {
        std::cout << "--Se inregistreaza mesajul trimis de utilizatorul cu username-ul " << this->Username << " .\n";

        std::string numeConversatie = "admin" + this->Username;
        std::wstring wideUsername(this->Username.begin(), this->Username.end());
        std::wstring wideMesaj(mesaj.begin(), mesaj.end());
        std::wstring wideNumeConversatie(numeConversatie.begin(), numeConversatie.end());
        std::wstring query = L"EXEC AdaugaConversatieSiMesaj2 @NumeConversatie= '" + wideNumeConversatie + L"',  @Username= '" + wideUsername + L"', @MesajText= '" + wideMesaj + L"'";
        if (SQL_SUCCESS != SQLExecDirect(DataBaseConnection::getInstance()->getSqlStmtHandle(), (SQLWCHAR*)query.c_str(), SQL_NTS))
        {
            std::cout << "Error querying SQL Server.\n";
            std::cout << "--Inregistrare mesaj esuata!\n";
            DataBaseConnection::getInstance()->disconnectDataBase();
            return "0";
        }
        else
        {
            std::cout << "--Mesajul s-a inregistrat cu succes!\n";
        }
        DataBaseConnection::getInstance()->disconnectDataBase();
        return "1";
        
    }
    else
        return "0";
}
