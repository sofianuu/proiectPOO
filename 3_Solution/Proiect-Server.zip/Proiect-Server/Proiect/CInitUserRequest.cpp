#include "CInitUserRequest.h"

std::string CInitUserRequest::executeRequest()
{
   
    char* nume = strtok(this->request, "#");
    nume = strtok(NULL, "#");
    char* prenume = strtok(NULL, "#");
    char* email = strtok(NULL, "#");
    char* gen = strtok(NULL, "#");
    char* dataNastere = strtok(NULL, "#");
    char* nrTelefon = strtok(NULL, "#");
    char* adresa = strtok(NULL, "#");
    CUser::getInstance(std::string(nume), std::string(prenume), std::string(adresa), std::string(nrTelefon), std::string(dataNastere), std::string(email), std::string(gen));
    return "1";
}
