#pragma once
#include "AUser.h"
#include "DataBaseConnection.h"

class CUser: public AUser
{
protected:
	CUser(std::string nume, std::string prenume, std::string adresa, std::string nrTelefon, std::string dataNastere, std::string email, std::string gen) :AUser(nume, prenume, adresa, nrTelefon, dataNastere, email, gen) {};
	static CUser* instance;
	CUser(const CUser&) {};
	CUser() {};
	CUser(std::string username, std::string passw) :AUser(username, passw) {};
	~CUser();

public:
	//metode pt user si admin
	static CUser* getInstance(std::string nume, std::string prenume, std::string adresa, std::string nrTelefon, std::string dataNastere, std::string email, std::string gen);
	static void deleteInstance();
	static CUser* getInstance();
	static CUser* getInstance(std::string username, std::string passw);
	const char * registerUser();
	void setPassword(std::string passw) override;
	void setUsername(std::string  username) override;
	const char* authentificateUser()override;
	const char* checkUsername(std::string username) override;
	std::string sendInformation()override;
	void getInformationFromDataBase()override;
	std::string getUsername() { return this->Username; };
	const char* updateInformations(std::string newNume, std::string newPrenume, std::string newAdress, std::string newMail, std::string newPassw, std::string newPhone, std::string newUsername) override;
	const char* addDonation(std::string suma) override;
	const char* addAdoptionRequest(std::string numeAnimal, std::string caleFormularAdoptie)override;
	const char* addMessage(std::string mesaj)override;

	//metode pt admin
	const char* authentificateAdmin()override { std::cout << "----Operatiune invalida!\n"; return "0"; };
	const char* addAnimal( const CAnimal& animal) override { std::cout << "----Operatiune invalida!\n"; return "0"; }
	const char* addOtherAnimalInformations(const CAnimal& animal)override { std::cout << "----Operatiune invalida!\n"; return "0"; };
	const char* aproveOrDenyAdoptionRequest(std::string caleFormularAdoptie, std::string Status)override { std::cout << "----Operatiune invalida!\n"; return "0"; };
	const char* addMessage(std::string mesaj, std::string usernameClient){ std::cout << "----Operatiune invalida!\n"; return "0"; }
};

