#pragma once
#include "ARequest.h"
class CUpdateUser :public ARequest
{
public:
	CUpdateUser(char request[1024]):ARequest(request){}
	CUpdateUser(){}
	std::string executeRequest() ;
};

