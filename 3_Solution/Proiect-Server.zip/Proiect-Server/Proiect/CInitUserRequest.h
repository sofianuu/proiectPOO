#pragma once
#include "ARequest.h"
class CInitUserRequest :public ARequest
{
public:
	CInitUserRequest(char request[1024]) :ARequest(request) {};
	CInitUserRequest() {};
	std::string executeRequest()override;
};

