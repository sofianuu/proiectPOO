#pragma once
#include "ARequest.h"
class CGetNrUsernamesRequest : public ARequest
{
public:
	CGetNrUsernamesRequest(char request[1024]) :ARequest(request) {};
	CGetNrUsernamesRequest() {}
	std::string executeRequest()override;

};

