#pragma once
#include <iostream>
#include "CAnimal.h"
class IUser
{
public:

	//metode specifice pt toti utilizatorii
	virtual const char * registerUser() = 0;
	virtual void setPassword(std::string passw) = 0;
	virtual void setUsername(std::string username) = 0;
	virtual const char* authentificateUser() = 0;
	virtual const char* checkUsername(std::string username)=0;
	virtual  std::string sendInformation() = 0;
	virtual void getInformationFromDataBase() = 0;
	virtual const char* addDonation(std::string suma)=0;
	virtual const char * updateInformations(std::string newNume, std::string newPrenume,std::string newAdress, std::string newMail,std::string newPassw, std::string newPhone, std::string newUsername) = 0;
	virtual const char* addAdoptionRequest(std::string numeAnimal, std::string caleFormularAdoptie)=0;
	virtual const char* addMessage(std::string mesaj) = 0;

	//metode specifice doar pentru admin
	virtual const char* authentificateAdmin() = 0;
	virtual const char* addAnimal(const CAnimal &animal) = 0;
	virtual const char* addOtherAnimalInformations(const CAnimal& animal)=0;
	virtual const char* aproveOrDenyAdoptionRequest(std::string caleFormularAdoptie, std::string Status) = 0;
	virtual const char* addMessage(std::string mesaj, std::string usernameClient) = 0;
};

