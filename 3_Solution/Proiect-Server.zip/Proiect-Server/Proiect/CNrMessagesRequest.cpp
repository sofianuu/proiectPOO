#include "CNrMessagesRequest.h"

std::string CNrMessagesRequest::executeRequest()
{
    if (DataBaseConnection::getInstance()->connectToDataBase() == true)
    {
        std::cout << "--Se preia nr de mesaje din conversatie.\n";

        std::string username = CUser::getInstance()->getUsername();
        std::string conversationName = "admin" + username;

        std::wstring wideName(conversationName.begin(), conversationName.end());

        SQLCHAR sqlVersion1[SQL_RESULT_LEN];
        SQLLEN ptrSqlVersion1;
        std::wstring query = L"exec GetMessageCountByConversationName '" + wideName + L"';";
        if (SQL_SUCCESS != SQLExecDirect(DataBaseConnection::getInstance()->getSqlStmtHandle(), (SQLWCHAR*)query.c_str(), SQL_NTS))
        {
            std::cout << "Error querying SQL Server.\n";
            std::cout << "--Preluare nr mesaje esuata!\n";
            DataBaseConnection::getInstance()->disconnectDataBase();
            return "0";
        }
        else
        {
            std::cout << "--Preluare nr mesaje reusita!\n";
            SQLCHAR sqlVersion1[SQL_RESULT_LEN];
            SQLLEN ptrSqlVersion1;
            if (SQLFetch(DataBaseConnection::getInstance()->getSqlStmtHandle()) == SQL_SUCCESS)
            {
                SQLGetData(DataBaseConnection::getInstance()->getSqlStmtHandle(), 1, SQL_CHAR, sqlVersion1, SQL_RESULT_LEN, &ptrSqlVersion1);
                DataBaseConnection::getInstance()->disconnectDataBase();
                std::string nr = std::string((char*)sqlVersion1);
                return nr;
            }
        }

    }
    else
        return "0";
}
