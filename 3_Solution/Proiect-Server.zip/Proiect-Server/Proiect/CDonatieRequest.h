#pragma once
#include "ARequest.h"
class CDonatieRequest :public ARequest
{
public:
	CDonatieRequest(char request[1024]) :ARequest(request){}
	CDonatieRequest() {};
	std::string executeRequest()override;
};

