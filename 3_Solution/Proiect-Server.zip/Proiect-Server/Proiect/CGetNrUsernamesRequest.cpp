#include "CGetNrUsernamesRequest.h"

std::string CGetNrUsernamesRequest::executeRequest()
{
    if (DataBaseConnection::getInstance()->connectToDataBase() == true)
    {
        std::cout << "--Se preia nr de username-uri.\n";
        SQLCHAR sqlVersion1[SQL_RESULT_LEN];
        SQLLEN ptrSqlVersion1;
        std::wstring query = L"exec GetNrUsernames2";
        if (SQL_SUCCESS != SQLExecDirect(DataBaseConnection::getInstance()->getSqlStmtHandle(), (SQLWCHAR*)query.c_str(), SQL_NTS))
        {
            std::cout << "Error querying SQL Server.\n";
            std::cout << "--Preluare nr username-uri esuata!\n";
            DataBaseConnection::getInstance()->disconnectDataBase();
            return "0";
        }
        else
        {
            std::cout << "--Preluare nr username-uri reusita!\n";
            SQLCHAR sqlVersion1[SQL_RESULT_LEN];
            SQLLEN ptrSqlVersion1;
            if (SQLFetch(DataBaseConnection::getInstance()->getSqlStmtHandle()) == SQL_SUCCESS)
            {
                SQLGetData(DataBaseConnection::getInstance()->getSqlStmtHandle(), 1, SQL_CHAR, sqlVersion1, SQL_RESULT_LEN, &ptrSqlVersion1);
                DataBaseConnection::getInstance()->disconnectDataBase();
                std::string nr = std::string((char*)sqlVersion1);
                return nr;
            }
        }

    }
    else
        return "0";
}
