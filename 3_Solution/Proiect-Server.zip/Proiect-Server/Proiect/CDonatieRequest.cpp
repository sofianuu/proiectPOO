#include "CDonatieRequest.h"

std::string CDonatieRequest::executeRequest()
{
    char* suma = strtok(this->request, "#");
    suma = strtok(NULL, "#");
    if (CUserAdmin::getInstance() != nullptr)
    {
        return CUserAdmin::getInstance()->addDonation(suma);
    }
    else
        return CUser::getInstance()->addDonation(suma);
}
