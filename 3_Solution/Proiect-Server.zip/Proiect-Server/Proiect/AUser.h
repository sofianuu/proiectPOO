#pragma once
#include "IUser.h"
class AUser :public IUser
{
protected:
	std::string Nume;
	std::string Prenume;
	std::string Adresa;
	std::string DataNastere;
	std::string DataInregistrare;
	std::string Email;
	std::string Parola;
	std::string Gen;
	std::string NrTelefon;
	std::string Username;
public:
	AUser(std::string nume, std::string prenume, std::string adresa, std::string nrTelefon, std::string dataNastere, std::string email, std::string gen);
	AUser() {};
	AUser(std::string username, std::string passw);
};

