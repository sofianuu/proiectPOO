#include "CCheckUNameRequest.h"

std::string CCheckUNameRequest::executeRequest()
{
    char* username = strtok(this->request, "#");
    username = strtok(NULL, "#");
 //   const char* buffer = CUser::getInstance()->checkUsername(std::string(username));
    return CUser::getInstance()->checkUsername(std::string(username));
}
