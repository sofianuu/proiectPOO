#pragma once
#include "ARequest.h"
class CLogUserRequest : public ARequest
{
public:
	CLogUserRequest(char request[1024]):ARequest(request){}
	CLogUserRequest() {};
	std::string executeRequest()override;
};

