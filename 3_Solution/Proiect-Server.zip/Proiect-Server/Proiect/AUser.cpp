#include "AUser.h"

AUser::AUser(std::string nume, std::string prenume, std::string adresa, std::string nrTelefon, std::string dataNastere, std::string email, std::string gen)
{
	this->Nume = nume;
	this->Prenume = prenume;
	this->Adresa = adresa;
	this->DataNastere = dataNastere;
	this->Gen = gen;
	this->Email = email;
	this->NrTelefon = nrTelefon;
}

AUser::AUser(std::string username, std::string passw)
{
	this->Parola = passw;
	this->Username = username;
}
