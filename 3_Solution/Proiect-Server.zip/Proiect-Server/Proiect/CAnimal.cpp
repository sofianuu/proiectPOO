#include "CAnimal.h"

CAnimal::CAnimal(std::string Nume, std::string DataNastere, std::string numeRasa, std::string Sterilizat, std::string DataSterilizare, std::string Descriere, std::string DataInregistrare, std::string Status, std::string CalefisaMedicala, std::string Caleimagine, std::string CaleDescriereAmanuntita)
{
	this->dataInregistrare = DataInregistrare;
	this->nume = Nume;
	this->dataNastere = DataNastere;
	this->dataSterilizare = DataSterilizare;
	this->descriere = Descriere;
	this->numeRasa = numeRasa;
	this->sterilizat = Sterilizat;
	this->status = Status;
	this->calefisaMedicala = CalefisaMedicala;
	this->caleDescriereAmanuntita = CaleDescriereAmanuntita;
	this->caleimagine = Caleimagine;
}

CAnimal::CAnimal(const CAnimal& obj)
{
	this->dataNastere = obj.dataNastere;
	this->dataSterilizare = obj.dataSterilizare;
	this->descriere = obj.descriere;
	this->nume = obj.nume;
	this->numeRasa = obj.numeRasa;
	this->sterilizat = obj.sterilizat;
	this->dataInregistrare = obj.dataInregistrare;
}

CAnimal::CAnimal(std::string Nume, std::string NumeRasa, std::string DataNastere, std::string Sterilizat, std::string DataSterilizarii, std::string Descriere, std::string status, std::string CalefisaMedicala, std::string Caleimagine, std::string CaleDescriereAmanuntita)
{
	this->nume = Nume;
	this->numeRasa = NumeRasa;
	this->dataNastere = DataNastere;
	this->sterilizat = Sterilizat;
	this->dataSterilizare = DataSterilizarii;
	this->descriere = Descriere;
	this->status = status;
	this->caleDescriereAmanuntita = CaleDescriereAmanuntita;
	this->calefisaMedicala = CalefisaMedicala;
	this->caleimagine = Caleimagine;
}


