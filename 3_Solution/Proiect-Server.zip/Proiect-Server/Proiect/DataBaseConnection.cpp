#include "DataBaseConnection.h"
DataBaseConnection* DataBaseConnection::instance = nullptr;

DataBaseConnection* DataBaseConnection::getInstance()
{
    if (DataBaseConnection::instance == nullptr)
    {
        DataBaseConnection::instance = new DataBaseConnection();
    }
    return instance;
}

void DataBaseConnection::deleteInstance()
{
    if (DataBaseConnection::instance != nullptr)
    {
        delete DataBaseConnection::instance;
        DataBaseConnection::instance = nullptr;
    }
}

//const char * DataBaseConnection::registerUser(std::string nume, std::string prenume, std::string email, std::string parola, std::string gen, std::string DataNastere, std::string nrTelefon, std::string adresa, std::string username)
//{
//    this->connectToDataBase();
//    std::wstring numeWide(nume.begin(), nume.end());
//    std::wstring prenumeWide(prenume.begin(), prenume.end());
//    std::wstring emailWide(email.begin(), email.end());
//    std::wstring parolaWide(parola.begin(), parola.end());
//    std::wstring genWide(gen.begin(), gen.end());
//    std::wstring DataNastereWide(DataNastere.begin(), DataNastere.end());
//    std::wstring nrTelefonWide(nrTelefon.begin(), nrTelefon.end());
//    std::wstring adresaWide(adresa.begin(), adresa.end());
//    std::wstring usernameWide(username.begin(), username.end());
//    std:: wstring query = L"INSERT INTO Utilizatori VALUES('" + numeWide + L"', '" + prenumeWide + L"', '" + emailWide + L"', '" + parolaWide + L"',GETDATE(),'" + genWide + L"', '" + DataNastereWide + L"', '" + nrTelefonWide + L"', '" + adresaWide + L"', '" + usernameWide + L"')";
//    if (SQL_SUCCESS != SQLExecDirect(sqlStmtHandle, (SQLWCHAR*)query.c_str(), SQL_NTS))
//    {
//        std::cout << "Error querying SQL Server.\n";
//        this->disconnectDataBase();
//        return "0";
//    }
//    else
//    {
//        std::cout << "Utilizator nou adaugat in baza de date!\n";
//    }
//    this->disconnectDataBase();
//    return "1";
//}
//
//const char* DataBaseConnection::authentificateUser(std::string username, std::string parola)
//{
//    this->connectToDataBase();
//     
//        if (SQL_SUCCESS != SQLExecDirect(sqlStmtHandle, (SQLWCHAR*)L"SELECT Username,Parola FROM Utilizatori", SQL_NTS))
//        {
//           std:: cout << "Error querying SQL Server.\n";
//           this->disconnectDataBase();
//        }
//        else
//        {
//            SQLCHAR sqlVersion1[SQL_RESULT_LEN];
//            SQLLEN ptrSqlVersion1;
//            SQLCHAR sqlVersion2[SQL_RESULT_LEN];
//            SQLLEN ptrSqlVersion2;
//            bool ok = 0;
//            while (SQLFetch(sqlStmtHandle) == SQL_SUCCESS)
//            {
//                SQLGetData(sqlStmtHandle, 1, SQL_CHAR, sqlVersion1, SQL_RESULT_LEN, &ptrSqlVersion1);
//                SQLGetData(sqlStmtHandle, 2, SQL_CHAR, sqlVersion2, SQL_RESULT_LEN, &ptrSqlVersion2);
//   
//                if (strcmp(username.c_str(), (char*)sqlVersion1) == 0 && strcmp(parola.c_str(), (char*)sqlVersion2) == 0)
//                {
//                    std::cout << "Utilizator existent!\n";
//                    return "1";
//                    break;
//                }
//            }
//            return "0";
//        }
//        return "0";
//
//
//
//}

//const char* DataBaseConnection::authentificateAdmin(std::string username, std::string parola)
//{
//    this->connectToDataBase();
//    SQLHANDLE sqlStmtHandle2;
//    SQLHANDLE sqlStmtHandle1;
//    
//    if (SQL_SUCCESS != SQLExecDirect(sqlStmtHandle, (SQLWCHAR*)L"SELECT Username, Parola FROM Utilizatori INNER JOIN Administratori ON Utilizatori.ID = Administratori.UtilizatorID", SQL_NTS))
//    {
//        std::cout << "Error querying SQL Server.\n";
//        this->disconnectDataBase();
//    }
//    else
//    {
//        SQLCHAR sqlVersion1[SQL_RESULT_LEN];
//        SQLLEN ptrSqlVersion1;
//        SQLCHAR sqlVersion2[SQL_RESULT_LEN];
//        SQLLEN ptrSqlVersion2;
//        bool ok = 0;
//        while (SQLFetch(sqlStmtHandle) == SQL_SUCCESS)
//        {
//            SQLGetData(sqlStmtHandle, 1, SQL_CHAR, sqlVersion1, SQL_RESULT_LEN, &ptrSqlVersion1);
//            SQLGetData(sqlStmtHandle, 2, SQL_CHAR, sqlVersion2, SQL_RESULT_LEN, &ptrSqlVersion1);
//            if (username == std::string((char*)sqlVersion1) && parola == std::string((char*)sqlVersion2))
//            {
//                std::cout << "----Administrator existent!\n";
//                this->disconnectDataBase();
//                return "1";
//            }
//            else
//                if (username == std::string((char*)sqlVersion1) && parola != std::string((char*)sqlVersion2))
//                {
//                    std::cout << "----Parola administrator gresita!\n";
//                    this->disconnectDataBase();
//                    return "0";
//
//                }
//            
//        }
//        this->disconnectDataBase();
//        std::cout << "----Utilazatorul nu se poate conecta ca administrator!\n";
//        return "2";
//    }
//
//    this->disconnectDataBase();
//
//}
//
//const char* DataBaseConnection::updateUsername(std::string username, std::string newUsername)
//{
//    this->connectToDataBase();
//    std::wstring usernameWide(username.begin(), username.end());
//    std::wstring newUsernameWide(newUsername.begin(), newUsername.end());
//    std::wstring query = L"UPDATE Utilizatori SET Username = '" + usernameWide + L"' WHERE Username = '" + newUsernameWide + L"'";
//    if (SQL_SUCCESS != SQLExecDirect(sqlStmtHandle, (SQLWCHAR*)query.c_str(), SQL_NTS))
//    {
//        std::cout << "Error querying SQL Server.\n";
//        this->disconnectDataBase();
//        return "0";
//    }
//    else
//    {
//        std::cout << "Username actualizat cu succes!\n";
//    }
//    this->disconnectDataBase();
//    return "1";
//}
//
//
//const char * DataBaseConnection::verifyUsername(std::string username)
//{
//    this->connectToDataBase();
//
//    if (SQL_SUCCESS != SQLExecDirect(sqlStmtHandle, (SQLWCHAR*)L"SELECT Username FROM Utilizatori", SQL_NTS))
//    {
//        std::cout << "Error querying SQL Server.\n";
//        this->disconnectDataBase();
//    }
//    else
//    {
//        SQLCHAR sqlVersion1[SQL_RESULT_LEN];
//        SQLLEN ptrSqlVersion1;
//        while (SQLFetch(sqlStmtHandle) == SQL_SUCCESS)
//        {
//            SQLGetData(sqlStmtHandle, 1, SQL_CHAR, sqlVersion1, SQL_RESULT_LEN, &ptrSqlVersion1);
//            if (strcmp(username.c_str(), (char*)sqlVersion1) == 0)
//            {
//                this->disconnectDataBase();
//                return "0";
//                break;
//            }
//        }
//        this->disconnectDataBase();
//        return "1";
//    }
//}

DataBaseConnection::DataBaseConnection()
{
	this->sqlConnHandle = NULL;
	this->sqlStmtHandle = NULL;
}

bool DataBaseConnection::connectToDataBase()
{
     sqlConnHandle = NULL;
     sqlStmtHandle = NULL;
    if (SQL_SUCCESS != SQLAllocHandle(SQL_HANDLE_ENV, SQL_NULL_HANDLE, &sqlEnvHandle))
    {
        std::cout << "Error connecting to database!(1)\n";
       return this->disconnectDataBase();
    }

    if (SQL_SUCCESS != SQLSetEnvAttr(sqlEnvHandle, SQL_ATTR_ODBC_VERSION, (SQLPOINTER)SQL_OV_ODBC3, 0))
    {
        std::cout << "Error connecting to database!(2)\n";
       return this->disconnectDataBase();
    }

    if (SQL_SUCCESS != SQLAllocHandle(SQL_HANDLE_DBC, sqlEnvHandle, &sqlConnHandle))
    {
        std::cout << "Error connecting to database!(3)\n";
        return this->disconnectDataBase();
    }
   
    switch (SQLDriverConnect(sqlConnHandle, NULL, (SQLWCHAR*)L"DRIVER={SQL SERVER};SERVER=localhost,49899;DATABASE=PetMatch;Trusted=true;",
        SQL_NTS,
        retconstring,
        1024,
        NULL,
        SQL_DRIVER_NOPROMPT))
    {
    case SQL_SUCCESS:
        std:: cout << "Successsfully connected to SQL Server.\n";
        break;
    case SQL_SUCCESS_WITH_INFO:
        std::cout << "Successfully connected to SQL Server(info).\n";
        break;
    case SQL_INVALID_HANDLE:
       std:: cout << "Could not connect to SQL Server.(1)\n";
       return  this->disconnectDataBase();
    case SQL_ERROR:
        std::cout << "Could not  connect to SQL Server.(2)\n";
       return this->disconnectDataBase();
    default:
        break;
        return false;
    }

    if (SQL_SUCCESS != SQLAllocHandle(SQL_HANDLE_STMT, sqlConnHandle, &sqlStmtHandle))
    {
        std::cout << "Could not connect to SQL Server.(3)\n";
        return this->disconnectDataBase();
        
    }
    return true;
}

bool DataBaseConnection::disconnectDataBase()
{
    SQLFreeHandle(SQL_HANDLE_STMT, sqlStmtHandle);
    SQLDisconnect(sqlConnHandle);
    SQLFreeHandle(SQL_HANDLE_DBC, sqlConnHandle);
    SQLFreeHandle(SQL_HANDLE_ENV, sqlEnvHandle);
    this->deleteInstance();
    std::cout << "Disconnected to database!\n";
    return false;
}

