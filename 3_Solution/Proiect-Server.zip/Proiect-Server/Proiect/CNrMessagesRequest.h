#pragma once
#include "ARequest.h"
class CNrMessagesRequest :public ARequest
{
public:
	CNrMessagesRequest(char request[1024]):ARequest(request){}
	CNrMessagesRequest(){}
	std::string executeRequest()override;

};

