#pragma once
#include "ARequest.h"

class CAddAnimalToDataBase : public ARequest
{
public:
	CAddAnimalToDataBase(char request[1024]) :ARequest(request) {};
	std::string executeRequest();
};

