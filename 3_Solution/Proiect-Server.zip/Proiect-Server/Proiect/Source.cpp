//#pragma comment (lib, "Ws2_32.lib")
//#include <iostream>
//#include <windows.h>
//#include <sqlext.h>
//#include <sqltypes.h>
//#include <sql.h>
#define _CRT_SECURE_NO_WARNINGS
// Need to link with Ws2_32.lib
#pragma comment (lib, "Ws2_32.lib")
#include "TCPServer.h"
#include "Utils.h"


int main() {
	sock_init();
	
//	TCPServer* server = TCPServer::getInstance(12345);
	// blocks untill someone connects
	char buffer[1024];
	char buffer2[20];
	while (1)
	{
		TCPServer::getInstance(12345)->wait_connection();

		TCPServer::getInstance()->send(TCPServer::getInstance()->getNrAnimals().c_str(), 2);
		int bytes = TCPServer::getInstance()->recv(buffer2, 20);
		buffer2[bytes] = '\0';

		if (strcmp(buffer2, "primit") == 0)
		{
			TCPServer::getInstance()->getAnimalsInformationsFromDataBase();

			for (;;)
			{
				int recv_bytes = TCPServer::getInstance()->recv(buffer, 1024);
				std::cout << "-> Informatii primite de la client: ";
				fwrite(buffer, 1, recv_bytes, stderr);
				std::cout << "\n";
			}
		}
	}
	/*while (1)
	{
		TCPServer::getInstance(12345)->wait_connection();
		for (;;)
		{
			int recv_bytes = TCPServer::getInstance()->recv(buffer, 1024);
			std::cout << "-> Informatii primite de la client: ";
			fwrite(buffer, 1, recv_bytes, stderr);
			std::cout << "\n";
		}
	}*/
	
}