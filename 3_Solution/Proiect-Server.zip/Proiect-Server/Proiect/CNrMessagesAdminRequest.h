#pragma once
#include "ARequest.h"
class CNrMessagesAdminRequest :  public ARequest
{
public:
	CNrMessagesAdminRequest(char request[1024]):ARequest(request){}
	CNrMessagesAdminRequest(){}
	std::string executeRequest() override;
};

