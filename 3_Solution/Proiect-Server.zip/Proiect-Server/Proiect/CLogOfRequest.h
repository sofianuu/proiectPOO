#pragma once
#include "ARequest.h"
class CLogOfRequest : public ARequest
{
public:
	CLogOfRequest(char request[1024]):ARequest(request){}
	CLogOfRequest(){}
	std::string executeRequest()override;
};

