#include "CAddAnimalToDataBase.h"

std::string CAddAnimalToDataBase::executeRequest()
{
    std::string nume = strtok(this->request, "#");
    nume = strtok(NULL, "#");
    std::string numeRasa = strtok(NULL, "#");
    std::string dataNastere = strtok(NULL, "#");
    std::string sterilizat = strtok(NULL, "#");
    std::string dataSterilizare = strtok(NULL, "#");
    std::string descriere = strtok(NULL, "#");
    std::string status = strtok(NULL, "#");
    std::string caleFisaMed = strtok(NULL, "#");
    std::string caleImagine = strtok(NULL, "#");
    std::string caleDescrAmanuntita = strtok(NULL, "#");
    CAnimal animal(nume, numeRasa, dataNastere, sterilizat, dataSterilizare, descriere, status, caleFisaMed, caleImagine, caleDescrAmanuntita);
    std::string addAnimal=CUserAdmin::getInstance()->addAnimal(animal);
    if (addAnimal == "1")
    {
        std::string otherInfo = CUserAdmin::getInstance()->addOtherAnimalInformations(animal);
        return otherInfo;
    }
    else
        return "0";
}
