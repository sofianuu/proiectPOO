#include "CUpdateUser.h"

std::string CUpdateUser::executeRequest()
{
    char* newNume = strtok(this->request, "#");
    newNume = strtok(NULL, "#");
    char* newPrenume = strtok(NULL, "#");
    char* newAdresa = strtok(NULL, "#");
    char* newMail = strtok(NULL, "#");
    char* newParola = strtok(NULL, "#");
    char* newTelefon = strtok(NULL, "#");
    char* newUsername = strtok(NULL, "#");
    if (CUserAdmin::getInstance() != nullptr)
    {
        if (std::string(newUsername) == CUserAdmin::getInstance()->getUsername())
        {
            return CUserAdmin::getInstance()->updateInformations(newNume, newPrenume, newAdresa, newMail, newParola, newTelefon, newUsername);
        }
        else
        {
            if (CUserAdmin::getInstance()->checkUsername(std::string(newUsername)) == "1")
                return CUserAdmin::getInstance()->updateInformations(newNume, newPrenume, newAdresa, newMail, newParola, newTelefon, newUsername);
            else
                return "2";
        }
        return CUserAdmin::getInstance()->updateInformations(newNume, newPrenume, newAdresa, newMail, newParola, newTelefon, newUsername);
    }
    else
    {
        if (std::string(newUsername) == CUser::getInstance()->getUsername())
            return CUser::getInstance()->updateInformations(newNume, newPrenume, newAdresa, newMail, newParola, newTelefon, newUsername);
        else
        {
            if (CUser::getInstance()->checkUsername(std::string(newUsername)) == "1")
                return CUser::getInstance()->updateInformations(newNume, newPrenume, newAdresa, newMail, newParola, newTelefon, newUsername);
            else
                return "0";
        }
    }
}
