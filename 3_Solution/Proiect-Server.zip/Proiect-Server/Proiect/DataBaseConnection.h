//#define _CRT_SECURE_NO_WARNINGS
//#pragma once
//#pragma comment (lib, "Ws2_32.lib")
//#include <iostream>
//#include <windows.h>
//#include <sqlext.h>
//#include <sqltypes.h>
//#include <sql.h>
//#include <string>
//#undef UNICODE
//#define WIN32_LEAN_AND_MEAN


#include <iostream>
#include <windows.h>
#include <sqlext.h>
#include <sqltypes.h>
#include <sql.h>
#include <string>

#define SQL_RESULT_LEN 240
#define SQL_RETURN_CODE_LEN 1000

class DataBaseConnection
{
private:

    SQLHANDLE sqlConnHandle;
    SQLHANDLE sqlStmtHandle;
    SQLHANDLE sqlEnvHandle;
    SQLWCHAR retconstring[SQL_RETURN_CODE_LEN];

    static DataBaseConnection* instance;
    DataBaseConnection();
    DataBaseConnection(const DataBaseConnection&) {};
    ~DataBaseConnection() {};

    

public:
    SQLHANDLE getSqlStmtHandle() { return this->sqlStmtHandle; }
    bool connectToDataBase();
    bool disconnectDataBase();
    static DataBaseConnection* getInstance();
    static void  deleteInstance();
   // const char * registerUser(std::string nume, std::string prenume, std::string email, std::string parola, std::string gen, std::string DataNastere, std::string nrTelefon, std::string adresa, std::string username);
  //  const char* verifyUsername(std::string username);
 //   const char *authentificateUser(std::string username, std::string parola);
   // const char* authentificateAdmin(std::string username, std::string parola);
    //const char* updateUsername(std::string username,std::string newUsername);
};

