#include "CLogOfRequest.h"

std::string CLogOfRequest::executeRequest()
{
	if (CUserAdmin::getInstance() != nullptr)
	{
		CUserAdmin::deleteInstance();
		std::cout << "Utilizatorul s-a deconectat din aplicatie!\n";
		return "1";
    }
	else
	{
		CUser::deleteInstance();
		std::cout << "Utilizatorul s-a deconectat din aplicatie!\n";
		return "1";
	}
	return "0";
}
