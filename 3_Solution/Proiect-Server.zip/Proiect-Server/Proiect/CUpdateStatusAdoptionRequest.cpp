#include "CUpdateStatusAdoptionRequest.h"

std::string CUpdateStatusAdoptionRequest::executeRequest()
{
    char* caleFormularAdoptie = strtok(this->request, "#");
    caleFormularAdoptie = strtok(NULL, "#");
    char* status = strtok(NULL , "#");

    return CUserAdmin::getInstance()->aproveOrDenyAdoptionRequest(std::string(caleFormularAdoptie),std::string(status));
}
