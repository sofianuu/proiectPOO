#include "CAddUNamePassRequest.h"

std::string CAddUNamePassRequest::executeRequest()
{
    char* username = strtok(this->request, "#");
    username = strtok(NULL, "#");
    char* passw = strtok(NULL, "#");
    if (CUser::getInstance() != nullptr)
    {
        CUser::getInstance()->setPassword(passw);
        CUser::getInstance()->setUsername(username);
        const char* buffer = CUser::getInstance()->registerUser();
        CUser::getInstance()->deleteInstance();
        return buffer;
    }
    else
        return "0";//inregistrare esuata
}
