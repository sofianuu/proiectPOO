#pragma once
#include "ARequest.h"
class CLogAdminRequest :public ARequest
{
public:
	CLogAdminRequest(char request[1024]) :ARequest(request) {};
	CLogAdminRequest() {};
	std::string executeRequest()override;
};

