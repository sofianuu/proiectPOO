#pragma once
#include "ARequest.h"
class CCheckUNameRequest : public ARequest
{
public:
	CCheckUNameRequest(char Request[1024]):ARequest(Request){}
	CCheckUNameRequest() {};
	std::string executeRequest()override;
};

