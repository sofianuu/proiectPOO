#pragma once
#include "CAddUNamePassRequest.h"
#include "CCheckUNameRequest.h"
#include "CInitUserRequest.h"
#include "CLogAdminRequest.h"
#include "CLogUserRequest.h"
#include "CUpdateUser.h"
#include "CAddAnimalToDataBase.h"
#include "CDonatieRequest.h"
#include "CAddAdoptionRequest.h"
#include "CAddMessageRequest.h"
#include "CUpdateStatusAdoptionRequest.h"
#include "CNrMessagesRequest.h"
#include "CNrMessagesAdminRequest.h"
#include "CLogOfRequest.h"
#include "CGetNrUsernamesRequest.h"


class CFactoryRequest
{
	static CFactoryRequest* instance;
	CFactoryRequest() {}
	~CFactoryRequest(){}
	CFactoryRequest(const CFactoryRequest &){}
public:
	static CFactoryRequest* getInstance();
	static void deleteInstance();
	IRequest* buildRequest(char request[1024]);
};

