#pragma once
#include "ARequest.h"
class CAddMessageRequest : public ARequest
{
public:
	CAddMessageRequest(char request[1024]):ARequest(request){}
	std::string executeRequest();
};

