#include "CLogAdminRequest.h"

std::string CLogAdminRequest::executeRequest()
{
    char* username = strtok(this->request, "#");
    username = strtok(NULL, "#");
    char* parola = strtok(NULL, "#");
    const char* ans = CUserAdmin::getInstance(username, parola)->authentificateAdmin();
    std::string buffer = std::string(ans);
    if (buffer=="2" || buffer== "0")
    {
        CUserAdmin::deleteInstance();
    }
    if (buffer=="1")
    {
        buffer =buffer+"#"+ CUserAdmin::getInstance()->sendInformation();
    }
    return buffer;
}
