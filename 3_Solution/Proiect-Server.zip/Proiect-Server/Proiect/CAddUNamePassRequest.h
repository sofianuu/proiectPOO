#pragma once
#include "ARequest.h"
class CAddUNamePassRequest :public ARequest
{
public:
	CAddUNamePassRequest(char request[1024]):ARequest(request){}
	CAddUNamePassRequest() {};
	std::string executeRequest()override;
};

