#pragma once
#include "ARequest.h"
class CUpdateStatusAdoptionRequest :public ARequest
{
public:
	CUpdateStatusAdoptionRequest(char request[1024]) :ARequest(request) {};
	CUpdateStatusAdoptionRequest() :ARequest(){}
	std::string executeRequest()override;
};

