#include "CAddAdoptionRequest.h"

std::string CAddAdoptionRequest::executeRequest()
{
    char* numeAnimal = strtok(this->request, "#");
    numeAnimal = strtok(NULL, "#");
    char* caleFormularAdoptie = strtok(NULL, "#");
    if (CUserAdmin::getInstance() != nullptr)
       return  CUserAdmin::getInstance()->addAdoptionRequest(std::string(numeAnimal),std::string(caleFormularAdoptie));
    else 
        return  CUser::getInstance()->addAdoptionRequest(std::string(numeAnimal),std::string( caleFormularAdoptie));
}
