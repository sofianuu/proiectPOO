#include "CFactoryRequest.h"
CFactoryRequest* CFactoryRequest::instance = nullptr;

CFactoryRequest* CFactoryRequest::getInstance()
{
	if (CFactoryRequest::instance == nullptr)
	{
		CFactoryRequest::instance = new CFactoryRequest();
	}
	return CFactoryRequest::instance;
}

void CFactoryRequest::deleteInstance()
{
	if (CFactoryRequest::instance != nullptr)
	{
		delete CFactoryRequest::instance;
		CFactoryRequest::instance = nullptr;
	}
}

IRequest * CFactoryRequest::buildRequest(char request[1024])
{
	switch (request[0])
	{
	case '1':
	{
		switch (request[1])
		{
		case '0':
			return new CAddMessageRequest(request);
		case '1':
			return new CUpdateStatusAdoptionRequest(request);
		case '2':
			return new CNrMessagesRequest(request);
		case '3':
			return new CGetNrUsernamesRequest(request);
		case '4':
			return new CNrMessagesAdminRequest(request);
		case '5':
			return new CLogOfRequest(request);
		}
		return new CInitUserRequest(request);
	}
	case '2':
		return new CCheckUNameRequest(request);
	case '3':
		return new CAddUNamePassRequest(request);
	case '4':
		return new CLogAdminRequest(request);
	case '5':
		return new CLogUserRequest(request);
	case '6':
		return new CUpdateUser(request);
	case '7':
		return new CAddAnimalToDataBase(request);
	case '8':
		return new CDonatieRequest(request);
	case '9':
		return new CAddAdoptionRequest(request);
	 
	default:
		return nullptr;
		break;
	}
}
