#define _CRT_SECURE_NO_WARNINGS
#include "Utils.h"
#include <winsock2.h>
#include <ws2tcpip.h>
#include <stdlib.h>
#include <stdio.h>
#pragma comment (lib, "Ws2_32.lib")
#include <iostream>
#include <windows.h>
#include <sqlext.h>
#include <sqltypes.h>
#include <sql.h>
#include <string>
#pragma once
#undef UNICODE
#define WIN32_LEAN_AND_MEAN

#include "CUser.h"
#include "CUserAdmin.h"
#include "CFactoryRequest.h"

class TCPServer
{
private:
	short port;
	struct addrinfo* result = NULL;
	struct addrinfo hints;
	SOCKET listen_sock = NULL;
	SOCKET client_sock = NULL;
	
	static TCPServer* instance;
	TCPServer(short listen_port);
	TCPServer(const TCPServer&) {};
	~TCPServer() {};

public:
	//TCPServer(short listen_port);
	static TCPServer* getInstance(short listen_port);
	static TCPServer* getInstance();
	static void deleteInstance();
	void wait_connection();
	int send(const char const* send_buf, const int size) const;
	int recv(char recv_buf[1024], const int size) const;
	void interpreteazaMesaj(char recv_buf[1024], int size) const;
	void getAnimalsInformationsFromDataBase() const;
	std::string getNrAnimals()const;
	void sendMessagesRequest() const;
	void sendUsernames()const;
	void sendMessagesRequest(std::string username) const;
};



