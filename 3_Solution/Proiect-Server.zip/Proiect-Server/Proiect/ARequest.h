#pragma once
#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
#include "IRequest.h"
class ARequest : public IRequest
{
protected:
	char request[1024];
public:
	ARequest(char Request[1024]) { strcpy(request, Request); }
	ARequest() {};
};

