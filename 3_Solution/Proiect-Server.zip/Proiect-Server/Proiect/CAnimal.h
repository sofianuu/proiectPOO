#pragma once
#include <iostream>


class CAnimal
{
private:
//	std::string ID;
	std::string dataInregistrare;
	std::string nume;
	std::string numeRasa;
	std::string dataNastere;
	std::string sterilizat;
	std::string dataSterilizare;
	std::string descriere;
	std::string status;
	std::string calefisaMedicala;
	std::string caleimagine;
	std::string caleDescriereAmanuntita;
public:
//	CAnimal() {};
	CAnimal(std::string Nume, std::string DataNastere, std::string numeRasa, std::string Sterilizat, std::string DataSterilizare, std::string Descriere,std::string DataInregistrare,std::string Status, std::string CalefisaMedicala,std::string Caleimagine,std::string CaleDescriereAmanuntita);
	CAnimal(const CAnimal& obj);
	CAnimal(std::string Nume,std::string NumeRasa,std::string DataNastere,std::string Sterilizat,std::string DataSterilizarii,std::string Descriere,std::string status, std::string CalefisaMedicala, std::string Caleimagine, std::string CaleDescriereAmanuntita);
	std::string getNume() const { return this->nume; };
	std::string getDataNastere() const  { return this->dataNastere; }
	std::string getSterilizare() const { return this->sterilizat; }
	std::string getDataSterilizare() const { return this->dataSterilizare; }
	std::string getRasa() const  { return this->numeRasa; }
 	std::string getDescriere() const  { return this->descriere; }
	std::string getDataInregistrare() const  { return this->dataInregistrare; }
	std::string getStatus()const { return this->status; }
	std::string getCaleImagine()const { return this->caleimagine; }
	std::string getCaleDescriere()const { return this->caleDescriereAmanuntita; }
	std::string getCaleFisaMed()const { return this->calefisaMedicala; }
	const std::string sendInformation() { return this->nume + "#" + this->numeRasa + "#" + this->descriere + "#" + this->dataNastere + "#" + this->sterilizat + "#" + this->dataSterilizare + "#" + this->dataInregistrare + "#" + this->calefisaMedicala + "#" + this->caleimagine + "#" + this->status + "#" + this->caleDescriereAmanuntita; }
};

