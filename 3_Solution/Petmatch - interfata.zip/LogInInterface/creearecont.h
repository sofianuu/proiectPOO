#ifndef CREEARECONT_H
#define CREEARECONT_H

#include <QDialog>
#include "tcpclient.h"

namespace Ui {
class CreeareCont;
}

class CreeareCont : public QDialog
{
    Q_OBJECT

public:
    explicit CreeareCont(QWidget *parent = nullptr);
    ~CreeareCont();
    QString getBuffer();
    QString getBufferClient();
    bool verificareDataNatere(QString data);
    bool verificareCampuri();
    bool verificareDiez(QString buffer);
    bool verificareCaracterSpecial();

private slots:
    void buttonCAccount();

protected:
    Ui::CreeareCont *ui;
    QString nume;
    QString prenume;
    QString adresa;
    QString DataNastere;
    QString gen;
    QString email;
    QString telefon;
};

#endif // CREEARECONT_H
