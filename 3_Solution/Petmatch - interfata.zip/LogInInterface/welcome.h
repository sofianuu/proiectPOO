#ifndef WELCOME_H
#define WELCOME_H

#include <QDialog>
#include "tcpclient.h"

namespace Ui {
class welcome;
}

class welcome : public QDialog
{
    Q_OBJECT

public:
    explicit welcome(QWidget *parent = nullptr);
    ~welcome();
    void primesteInfAnimale();
private slots:
    void buttonLogIn();
    void buttonCreateAccount();

private:
    Ui::welcome *ui;
};

#endif // WELCOME_H
