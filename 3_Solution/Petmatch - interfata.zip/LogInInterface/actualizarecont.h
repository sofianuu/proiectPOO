#ifndef ACTUALIZARECONT_H
#define ACTUALIZARECONT_H

#include <QDialog>

namespace Ui {
class actualizareCont;
}

class actualizareCont : public QDialog
{
    Q_OBJECT

public:
    explicit actualizareCont(QWidget *parent = nullptr);


    ~actualizareCont();


    void initializeWindow(QString buffer);
    QString setNewName();
    QString setNewSurname();
    QString setNewAdress();
    QString setNewCellphone();
    QString setNewEmail();
    QString setNewPassword();
    QString setNewUsername();

    bool checkUsername(QString username);
    void checkCharacter(QString buffer);
    bool checkPassword(QString password);
    QString hashPassword(const QString& password);
    void readOption();

signals:
    void resultReady(const QString &result);
    void updateData(const QString &optiune, const QString &newValue);  // Adăugat semnal nou

private slots:
    void button();
    void handleButtonClick();

private:
    Ui::actualizareCont *ui;

    QString optiune;

};

#endif // ACTUALIZARECONT_H
