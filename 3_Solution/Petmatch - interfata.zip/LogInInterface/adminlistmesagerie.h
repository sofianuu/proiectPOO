#ifndef ADMINLISTMESAGERIE_H
#define ADMINLISTMESAGERIE_H

#include <QDialog>
#include<QVBoxLayout>
#include"chatadmin.h"

namespace Ui {
class adminListMesagerie;
}

class adminListMesagerie : public QDialog
{
    Q_OBJECT

public:
    explicit adminListMesagerie(QWidget *parent = nullptr);
    ~adminListMesagerie();

    void primesteUsername();

private:
    Ui::adminListMesagerie *ui;

    QVBoxLayout* layout;
};

#endif // ADMINLISTMESAGERIE_H
