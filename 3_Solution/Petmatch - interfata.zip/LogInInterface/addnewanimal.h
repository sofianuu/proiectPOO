#ifndef ADDNEWANIMAL_H
#define ADDNEWANIMAL_H

#include <QDialog>
#include <QLineEdit>
#include <QPushButton>

namespace Ui {
class AddNewAnimal;
}

class AddNewAnimal : public QDialog
{
    Q_OBJECT

public:
    explicit AddNewAnimal(QWidget *parent = nullptr);
    ~AddNewAnimal();

private slots:
    void onSaveButtonClicked();

private:
    QLineEdit *numeEdit;
    QLineEdit *rasaEdit;
    QLineEdit *descriereEdit;
    QLineEdit *dataNastereEdit;
    QLineEdit *stareSterilizareEdit;
    QLineEdit *dataSterilizareEdit;
    QLineEdit *fisaMedicalaEdit;
    QLineEdit *imagineEdit;
    QLineEdit *statusEdit;
    QLineEdit *descriereAmanuntitaEdit;

    Ui::AddNewAnimal *ui;
};

#endif // ADDNEWANIMAL_H
