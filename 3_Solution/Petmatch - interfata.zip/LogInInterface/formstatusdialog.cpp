#include "formstatusdialog.h"
#include "ui_formstatusdialog.h"
#include <QVBoxLayout>
#include <QFile>
#include <QTextStream>
#include <QDebug>


FormStatusDialog::FormStatusDialog(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::FormStatusDialog)
{
    ui->setupUi(this);

    QVBoxLayout *layout = new QVBoxLayout(this);

    nameLineEdit = new QLineEdit(this);
    QPushButton *checkButton = new QPushButton("Verifică Starea", this);
    statusLabel = new QLabel(this);

    connect(checkButton, &QPushButton::clicked, this, &FormStatusDialog::checkFormStatus);

    layout->addWidget(new QLabel("Introduceți numele complet:", this));
    layout->addWidget(nameLineEdit);
    layout->addWidget(checkButton);
    layout->addWidget(statusLabel);

    setLayout(layout);
}

FormStatusDialog::~FormStatusDialog()
{
    delete ui;
}

void FormStatusDialog::checkFormStatus() {
    QString username = nameLineEdit->text();
    QString status = getFormStatus(username);
    if (!status.isEmpty()) {
        statusLabel->setText("Stare formular: " + status);
    } else {
        statusLabel->setText("Formularul nu a fost găsit.");
    }
}

QString FormStatusDialog::getFormStatus(const QString &username) {
    QString filename = "D:/Qt_bun/POO/LogInInterface/formulareAdoptie/" + username + ".txt";  // Asigură-te că ai calea corectă aici
    QFile file(filename);

    if (file.open(QIODevice::ReadOnly | QIODevice::Text)) {
        QTextStream in(&file);
        while (!in.atEnd()) {
            QString line = in.readLine();
            if (line.startsWith("Stare formular:")) {
                return line.mid(QString("Stare formular:").length()).trimmed();
            }
        }
        file.close();
    }
    return "";
}
