#ifndef UTILS_H
#define UTILS_H

#pragma once
int sock_init();

#endif // UTILS_H
