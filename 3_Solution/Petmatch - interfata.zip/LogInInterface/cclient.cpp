#include "cclient.h"
#include<cstring>
#include<iostream>
#include<qstring>

CClient* CClient::instance=nullptr;

CClient* CClient::getInstance()
{
    if(!instance)
        instance=new CClient();
    return instance;
}

void CClient::setPassword(QString buffer)
{
    password=buffer;
}

void CClient::setUsername(QString buffer)
{
    username=buffer;
}

CClient* CClient::getInstance7(QString ufirstname,QString ulastname,QString uadress,QString uemail,QString ucellphone,QString usex,QString ubirthdate)
{
    if(instance==nullptr)
        instance=new CClient(ufirstname,ulastname,uadress,uemail,ucellphone,usex,ubirthdate);
    return instance;
}

CClient* CClient::getInstance2(QString uusername, QString upassword)
{
    if(instance==nullptr)
        instance=new CClient(uusername,upassword);
    return instance;
}

void CClient::destroyInstance()
{
    if(instance!=nullptr)
    {
        delete instance;
        instance=nullptr;
    }
}

void CClient::afiseaza()
{
    std::cout << "Nume: " << lastname.toStdString() << std::endl;
    std::cout << "Prenume: " << firstname.toStdString() << std::endl;
    std::cout << "Email: " << email.toStdString() << std::endl;
    std::cout << "Gen: " << sex.toStdString() << std::endl;
    std::cout << "Data Nastere: " << birthdate.toStdString() << std::endl;
    std::cout << "Telefon: " << cellphone.toStdString() << std::endl;
    std::cout << "Adresa: " << adress.toStdString() << std::endl;
    std::cout << "Username: " << username.toStdString() << std::endl;
    std::cout << "Parola: " << password.toStdString() << std::endl;
}

void CClient::setId()
{
    id=1;
}
