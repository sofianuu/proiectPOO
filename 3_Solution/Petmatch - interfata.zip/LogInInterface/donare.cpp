#include "donare.h"
#include "ui_donare.h"
#include "tcpclient.h"
#include<QMessageBox>

donare::donare(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::donare)
{
    ui->setupUi(this);
    connect(ui->pushButton,SIGNAL(clicked()),this,SLOT(trimiteDonare()));
}

donare::~donare()
{
    delete ui;
}

QString donare::getBuffer()
{
    suma=ui->lineEdit->text();

    QString buffer=QString("8")+"#"+suma;

    return buffer;
}

void donare::trimiteDonare()
{
    QString buffer=this->getBuffer();

    const char* buff=buffer.toUtf8().constData();
    TCPClient::getInstance()->send(buff,strlen(buff));

    char answerBuffer[1024];
    int recv_bytes=TCPClient::getInstance()->recv(answerBuffer,1024);
    answerBuffer[recv_bytes]='\0';
    if(answerBuffer[0]='1')
    {
        std::cout<<"Donare reusita!"<<std::endl;
        QMessageBox::information(this,"Donare reusita!","Multumim pentru sprijinul acordat!");
        this->hide();
    }
    else if(answerBuffer[0]='0')
    {
        std::cout<<"Donare nereusita!","Introduceti inca o data suma!";
        ui->lineEdit->clear();
    }
}

