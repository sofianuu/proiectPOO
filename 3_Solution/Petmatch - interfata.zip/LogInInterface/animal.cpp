#include "animal.h"

Animal::Animal() {}

Animal::Animal( QString unume,
       QString urasa,
       QString udescriere,
       QString udataNastere,
       QString ustareSterilizare,
       QString udataSterilizare,
       QString udataInregistrare,
       QString ufisaMedicala,
       QString uimagine,
       QString ustatus,
       QString udescriereAmanuntita)
{
    this->nume=unume;
    this->rasa=urasa;
    this->descriere=udescriere;
    this->dataNastere=udataNastere;
    this->stareSterilizare=ustareSterilizare;
    this->dataSterilizare=udataSterilizare;
    this->dataInregistrare=udataInregistrare;
    this->fisaMedicala=ufisaMedicala;
    this->imagine=uimagine;
    this->status=ustatus;
    this->descriereAmanuntita=udescriereAmanuntita;
}
