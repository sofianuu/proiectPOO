#include "inregistraresucces.h"
#include "ui_inregistraresucces.h"
#include"mainwindow.h"

InregistrareSucces::InregistrareSucces(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::InregistrareSucces)
{
    ui->setupUi(this);
    QPixmap pix("D:/Qt_bun/POO/LogInInterface/succes.jpg");
    ui->img->setPixmap(pix.scaled(500,500,Qt::KeepAspectRatio));

    timer = new QTimer(this);

    // Setează intervalul timerului la 3000 ms (3 secunde)
    timer->setInterval(3000);

    // Conectează semnalul timeout() al timerului la slot-ul nostru custom
    connect(timer, SIGNAL(timeout()), this, SLOT(close()));

    //connect(timer, SIGNAL(timeout()), this, SLOT(onTimerExpired()));

    // Pornirea timerului
    timer->start();

    mainWindow::getInstance()->primesteDateAnimale();

}


InregistrareSucces::~InregistrareSucces()
{

    delete ui;
}
