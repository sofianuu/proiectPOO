#ifndef ADMINWINDOW_H
#define ADMINWINDOW_H

#include <QDialog>
#include <QWidget>
#include <QListWidget>
#include <QPushButton>
#include <QTextEdit>

namespace Ui {
class AdminWindow;
}

class AdminWindow : public QDialog
{
    Q_OBJECT

public:
    explicit AdminWindow(QWidget *parent = nullptr);
    ~AdminWindow();

    void updateFormStatus(const QString &status);
    void sendInformation(QString optiune);

private slots:
    void loadFormData();
    void acceptForm();
    void rejectForm();

private:
    Ui::AdminWindow *ui;

    void setupWidgets();
    void loadFormList();
    QString getSelectedFormPath();

    QListWidget *formListWidget;
    QTextEdit *formDetailsTextEdit;
    QPushButton *acceptButton;
    QPushButton *rejectButton;

};

#endif // ADMINWINDOW_H
