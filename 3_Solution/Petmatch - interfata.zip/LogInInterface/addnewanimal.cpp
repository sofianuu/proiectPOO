#include "addnewanimal.h"
#include "ui_addnewanimal.h"
#include <QVBoxLayout>
#include <QLabel>
#include <QFileDialog>
#include"tcpclient.h"
#include<QMessageBox>

AddNewAnimal::AddNewAnimal(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::AddNewAnimal)
{
    ui->setupUi(this);

    QVBoxLayout *layout = new QVBoxLayout(this);

    numeEdit = new QLineEdit(this);
    layout->addWidget(new QLabel("Nume:", this));
    layout->addWidget(numeEdit);

    rasaEdit = new QLineEdit(this);
    layout->addWidget(new QLabel("Rasa:", this));
    layout->addWidget(rasaEdit);

    descriereEdit = new QLineEdit(this);
    layout->addWidget(new QLabel("Descriere:", this));
    layout->addWidget(descriereEdit);

    dataNastereEdit = new QLineEdit(this);
    layout->addWidget(new QLabel("Data Naștere:", this));
    layout->addWidget(dataNastereEdit);

    stareSterilizareEdit = new QLineEdit(this);
    layout->addWidget(new QLabel("Stare Sterilizare:", this));
    layout->addWidget(stareSterilizareEdit);

    dataSterilizareEdit = new QLineEdit(this);
    layout->addWidget(new QLabel("Data Sterilizare:", this));
    layout->addWidget(dataSterilizareEdit);

    fisaMedicalaEdit = new QLineEdit(this);
    layout->addWidget(new QLabel("Fișa Medicală:", this));
    layout->addWidget(fisaMedicalaEdit);

    QPushButton *browseFisaMedicalaButton = new QPushButton("Browse...", this);
    layout->addWidget(browseFisaMedicalaButton);
    connect(browseFisaMedicalaButton, &QPushButton::clicked, [this]() {
        QString fileName = QFileDialog::getOpenFileName(this, "Select Fișa Medicală");
        if (!fileName.isEmpty()) {
            fisaMedicalaEdit->setText(fileName);
        }
    });

    imagineEdit = new QLineEdit(this);
    layout->addWidget(new QLabel("Imagine:", this));
    layout->addWidget(imagineEdit);

    QPushButton *browseImagineButton = new QPushButton("Browse...", this);
    layout->addWidget(browseImagineButton);
    connect(browseImagineButton, &QPushButton::clicked, [this]() {
        QString fileName = QFileDialog::getOpenFileName(this, "Select Imagine");
        if (!fileName.isEmpty()) {
            imagineEdit->setText(fileName);
        }
    });

    statusEdit = new QLineEdit(this);
    layout->addWidget(new QLabel("Status:", this));
    layout->addWidget(statusEdit);

    descriereAmanuntitaEdit = new QLineEdit(this);
    layout->addWidget(new QLabel("Descriere Amanunțită:", this));
    layout->addWidget(descriereAmanuntitaEdit);

    QPushButton *browseDescriereAmanuntitaButton = new QPushButton("Browse...", this);
    layout->addWidget(browseDescriereAmanuntitaButton);
    connect(browseDescriereAmanuntitaButton, &QPushButton::clicked, [this]() {
        QString fileName = QFileDialog::getOpenFileName(this, "Select Descriere Amanunțită");
        if (!fileName.isEmpty()) {
            descriereAmanuntitaEdit->setText(fileName);
        }
    });

    QPushButton *saveButton = new QPushButton("Save", this);
    layout->addWidget(saveButton);
    connect(saveButton, &QPushButton::clicked, this, &AddNewAnimal::onSaveButtonClicked);
}

AddNewAnimal::~AddNewAnimal()
{
    delete ui;
}

void AddNewAnimal::onSaveButtonClicked()
{
    QString nume = numeEdit->text();
    QString rasa = rasaEdit->text();
    QString descriere = descriereEdit->text();
    QString dataNastere = dataNastereEdit->text();
    QString stareSterilizare = stareSterilizareEdit->text();
    QString dataSterilizare = dataSterilizareEdit->text();
    QString fisaMedicala = fisaMedicalaEdit->text();
    QString imagine = imagineEdit->text();
    QString status = statusEdit->text();
    QString descriereAmanuntita = descriereAmanuntitaEdit->text();

    char answer[1024];
    QString buff=QString("7")+"#"+nume+"#"+rasa+"#"+dataNastere+"#"+stareSterilizare+"#"+dataSterilizare+"#"+descriere+"#"+status+"#"+fisaMedicala+"#"+imagine+"#"+descriereAmanuntita;
    const char* buffer=buff.toUtf8().constData();
    TCPClient::getInstance()->send(buffer,strlen(buffer));
    int recv_bytes=TCPClient::getInstance()->recv(answer,1024);
    answer[recv_bytes]='\0';
    if(answer[0]='1')
    {
        QMessageBox::information(this,"Adaugare animal","Animalul a fost adaugat cu succes!");
    }
    else if(answer[0]='0')
    {
        QMessageBox::information(this,"Adaugare animal","Animalul nu a fost adaugat!");
    }
    this->close();
}
