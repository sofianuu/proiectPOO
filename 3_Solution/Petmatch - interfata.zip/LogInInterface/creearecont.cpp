#include "creearecont.h"
#include "ui_creearecont.h"
#include "setpassword.h"
#include "cclient.h"
#include"qmessagebox.h"
#include<iostream>
#include<qdebug.h>

CreeareCont::CreeareCont(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::CreeareCont)
{
    ui->setupUi(this);
    connect(ui->pushButton,SIGNAL(clicked()),this,SLOT(buttonCAccount()));
    ui->comboBox->addItem("Feminin");
    ui->comboBox->addItem("Masculin");
    ui->label_10->setVisible(false);

    ui->lineEdit_3->setPlaceholderText("AAAA-LL-ZZ");

}

CreeareCont::~CreeareCont()
{
    delete ui;
}

QString CreeareCont::getBuffer()
{
    nume=ui->lineEdit->text();
    prenume=ui->lineEdit_2->text();
    DataNastere=ui->lineEdit_3->text();
    adresa=ui->lineEdit_4->text();
    telefon=ui->lineEdit_5->text();
    email=ui->lineEdit_6->text();
    gen=ui->comboBox->currentText();


    CClient::getInstance7(prenume,nume,adresa,email,telefon,gen,DataNastere);

    QString buffer=QString("1")+"#"+nume+"#"+prenume+"#"+email+"#"+gen+"#"+DataNastere+"#"+telefon+"#"+adresa+"#";

    return buffer;
}

QString CreeareCont::getBufferClient()
{
    QString buffer=nume+"#"+prenume+"#"+email+"#"+gen+"#"+DataNastere+"#"+telefon+"#"+adresa+"#";

    std::cout<<"nume: "<<nume.toStdString()<<std::endl;
    std::cout<<"prenume: "<<prenume.toStdString()<<std::endl;
    std::cout << "buffer: " << buffer.toStdString() << std::endl;

    return buffer;
}

bool CreeareCont::verificareCampuri()
{
    if(nume.isEmpty() || prenume.isEmpty() || adresa.isEmpty() || DataNastere.isEmpty() || email.isEmpty() || telefon.isEmpty())
    {
        ui->label_10->setVisible(true);
        return false;
    }
    else
    {
        ui->label_10->setVisible(false);
        return true;
    }
}

bool CreeareCont::verificareDiez(QString buffer)
{
    if(buffer.contains("#"))
        return true;

    return false;
}

bool CreeareCont::verificareCaracterSpecial()
{
    if(verificareDiez(nume) || verificareDiez(prenume) || verificareDiez(adresa) || verificareDiez(DataNastere) || verificareDiez(email) || verificareDiez(telefon))
    {
        ui->label_9->setVisible(true);
        return false;
    }
    else
    {
        ui->label_9->setVisible(false);
        return true;
    }
}


bool CreeareCont::verificareDataNatere(QString data)
{
    QRegularExpression dateRegex("(\\d{4})[-\\.]?(\\d{2})[-\\.]?(\\d{2})");

    QRegularExpressionMatch match = dateRegex.match(data);
    if (!match.hasMatch()) {
        return false;
    }

    int year = match.captured(1).toInt();
    int month = match.captured(2).toInt();
    int day = match.captured(3).toInt();

    if (year < 0 || month < 1 || month > 12 || day < 1 || day > 31)
    {
        return false;
    }

    int daysInMonth[] = {31, (year % 4 == 0 && year % 100 != 0) || (year % 400 == 0) ? 29 : 28,
                         31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
    if (day > daysInMonth[month - 1]) {
        return false;
    }

    return true;
}

void CreeareCont::buttonCAccount()
{
    QString buff=this->getBuffer();

    if(verificareCampuri()==true && verificareCaracterSpecial()==true)
    {
        if(verificareDataNatere(DataNastere)==false)
        {
            QMessageBox::critical(this,"Eroare","Data de nastere nu coincide cu formatul precizat!""\n""Incercati din nou!");
            ui->lineEdit_3->clear();
        }
        else
        {
            const char* buffer=buff.toUtf8().constData();
            TCPClient::getInstance()->send(buffer,strlen(buffer));

            char answerBuffer[1024];
            int recv_bytes=TCPClient::getInstance()->recv(answerBuffer,1024);
            answerBuffer[recv_bytes]='\0';
            if(answerBuffer[0]='1')
            {
                std::cout<<"Datele au fost trimise cu succes!"<<std::endl;
            }

            this->hide();
            SetPassword* pass= new SetPassword;
            pass->show();
        }
    }
}

