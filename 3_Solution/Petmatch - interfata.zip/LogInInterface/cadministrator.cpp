#include "cadministrator.h"

CAdministrator* CAdministrator::instance=nullptr;

CAdministrator* CAdministrator::getInstance()
{
    if(instance!=nullptr)
         return instance;
    return nullptr;
}

void CAdministrator::destroyInstance()
{
    if(instance)
    {
        delete instance;
        instance=nullptr;
    }
}

CAdministrator* CAdministrator::getInstance2(QString uusername, QString upassword)
{
    if(!instance)
        instance=new CAdministrator(uusername,upassword);
    return instance;
}

void CAdministrator::setId()
{
    id=0;
}
