#include "aclient.h"
#include<iostream>
#include<qdebug>

AClient::AClient(QString ufirstname,QString ulastname,QString uadress,QString uemail,QString ucellphone,QString usex,QString ubirthdate)
{
    this->firstname=ufirstname;
    this->lastname=ulastname;
    this->adress=uadress;
    this->email=uemail;
    this->cellphone=ucellphone;
    this->sex=usex;
    this->birthdate=ubirthdate;
}

AClient::AClient(QString uusername,QString upassword)
{
    this->username=uusername;
    this->password=upassword;
}

void AClient::setData(QString buffer)
{
    QByteArray byteArray = buffer.toUtf8();
    const char *cStr = byteArray.constData();

    char *cStrCopy = strdup(cStr);
    QString code;

    char *token = strtok(cStrCopy, "#");
    if (token != nullptr)
    {
        code=token;
        lastname = strtok(nullptr,"#");
        firstname = strtok(nullptr, "#");
        email = strtok(nullptr, "#");
        sex = strtok(nullptr, "#");
        birthdate = strtok(nullptr, "#");
        cellphone = strtok(nullptr, "#");
        adress = strtok(nullptr, "#");
    }

    this->setId();

    std::cout<<"ID: "<<id<<std::endl;
    std::cout << "Nume: " << lastname.toStdString() << std::endl;
    std::cout << "Prenume: " << firstname.toStdString() << std::endl;
    std::cout << "Email: " << email.toStdString() << std::endl;
    std::cout << "Gen: " << sex.toStdString() << std::endl;
    std::cout << "Data Nastere: " << birthdate.toStdString() << std::endl;
    std::cout << "Telefon: " << cellphone.toStdString() << std::endl;
    std::cout << "Adresa: " << adress.toStdString() << std::endl;
    std::cout << "Username: " << username.toStdString() << std::endl;
    std::cout << "Password: " << password.toStdString() << std::endl;
}
