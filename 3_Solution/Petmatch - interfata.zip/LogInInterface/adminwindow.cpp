#include "adminwindow.h"
#include "ui_adminwindow.h"
#include <QVBoxLayout>
#include <QDir>
#include <QFile>
#include <QTextStream>
#include <QDebug>
#include"tcpclient.h"
#include<QMessageBox>
#include<iostream>


AdminWindow::AdminWindow(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::AdminWindow)
{
    ui->setupUi(this);
    setupWidgets();
    loadFormList();
}

AdminWindow::~AdminWindow()
{
    delete ui;
}

void AdminWindow::setupWidgets() {
    QVBoxLayout *layout = new QVBoxLayout(this);

    formListWidget = new QListWidget(this);
    formDetailsTextEdit = new QTextEdit(this);
    acceptButton = new QPushButton("Acceptă", this);
    rejectButton = new QPushButton("Respinge", this);

    connect(formListWidget, &QListWidget::itemSelectionChanged, this, &AdminWindow::loadFormData);
    connect(acceptButton, &QPushButton::clicked, this, &AdminWindow::acceptForm);
    connect(rejectButton, &QPushButton::clicked, this, &AdminWindow::rejectForm);

    layout->addWidget(formListWidget);
    layout->addWidget(formDetailsTextEdit);
    layout->addWidget(acceptButton);
    layout->addWidget(rejectButton);

    setLayout(layout);
}

void AdminWindow::loadFormList() {
    QDir dir("D:/Qt_bun/POO/LogInInterface/formulareAdoptie");
    QStringList files = dir.entryList(QStringList() << "*.txt", QDir::Files);
    formListWidget->addItems(files);
}

void AdminWindow::loadFormData() {
    QString selectedFormPath = getSelectedFormPath();
    if (!selectedFormPath.isEmpty()) {
        QFile file(selectedFormPath);
        if (file.open(QIODevice::ReadOnly | QIODevice::Text)) {
            QTextStream in(&file);
            formDetailsTextEdit->setPlainText(in.readAll());
            formDetailsTextEdit->setReadOnly(true);
            file.close();
        }
    }
}

void AdminWindow::updateFormStatus(const QString &status) {
    QString selectedFormPath = getSelectedFormPath();
    if (!selectedFormPath.isEmpty()) {
        QFile file(selectedFormPath);
        if (file.open(QIODevice::ReadWrite | QIODevice::Text)) {
            QTextStream in(&file);
            QStringList lines;
            while (!in.atEnd()) {
                lines.append(in.readLine());
            }
            file.resize(0); // Șterge conținutul fișierului
            QTextStream out(&file);
            for (QString &line : lines) {
                if (line.startsWith("Stare formular:")) {
                    line = "Stare formular: " + status;
                }
                out << line << "\n";
            }
            file.close();
            loadFormData(); // Reîncarcă datele formularului pentru a afișa noua stare
            this->sendInformation(status);
        }
    }
}

void AdminWindow::acceptForm() {
    updateFormStatus("Acceptat");
}

void AdminWindow::rejectForm() {
    updateFormStatus("Respins");
}


QString AdminWindow::getSelectedFormPath() {
    QListWidgetItem *selectedItem = formListWidget->currentItem();
    if (selectedItem) {
        return "D:/Qt_bun/POO/LogInInterface/formulareAdoptie/" + selectedItem->text();
    }
    return "";
}

void AdminWindow::sendInformation(QString optiune)
{
    QString buff=QString("11")+"#"+this->getSelectedFormPath()+"#"+optiune;
    std::cout<<buff.toStdString()<<std::endl;
    const char* buffer=buff.toUtf8().constData();
    TCPClient::getInstance()->send(buffer,strlen(buffer));
    char answer[1024];
    int recv_bytes=TCPClient::getInstance()->recv(answer,1024);
    answer[recv_bytes]='\0';
    if(answer[0]='1')
    {
        QMessageBox::information(this,"Stare formular","Starea formularului a fost modificata cu succes!");
    }
    else if(answer[0]='0')
    {
        QMessageBox::information(this,"Stare formular","Starea formularului nu a fost modificata!");
    }
}

