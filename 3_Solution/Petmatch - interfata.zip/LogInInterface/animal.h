#ifndef ANIMAL_H
#define ANIMAL_H
#include<QString>

class Animal
{
public:
    Animal();
    Animal( QString unume,
           QString urasa,
           QString udescriere,
           QString udataNastere,
           QString ustareSterilizare,
           QString udataSterilizare,
           QString udataInregistrare,
           QString ufisaMedicala,
           QString uimagine,
           QString ustatus,
           QString udescriereAmanuntita);
    const QString getNume() const {return nume;}
    const QString getRasa()const {return rasa;}
    const QString getDataNastere()const {return dataNastere;}
    const QString getDescriere()const {return descriere;}
    const QString getStatus()const {return status;}
    const QString getImagine()const {return imagine;}
    const QString getStareSterilizare() const {return stareSterilizare;}
    const QString getDescriereAmanuntita() const {return descriereAmanuntita;}
    const QString getFisaMedicala() const {return fisaMedicala;}
    void setStatus(QString ustatus){status=ustatus;}
private:
    QString nume;
    QString rasa;
    QString descriere;
    QString dataNastere;
    QString stareSterilizare;
    QString dataSterilizare;
    QString dataInregistrare;
    QString fisaMedicala;
    QString imagine;
    QString status;
    QString descriereAmanuntita;


};

#endif // ANIMAL_H
