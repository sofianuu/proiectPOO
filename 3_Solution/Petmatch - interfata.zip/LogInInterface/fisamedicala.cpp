#include "fisamedicala.h"
#include "ui_fisamedicala.h"

#include <QFile>
#include <QTextStream>
#include <QVBoxLayout>
#include <QMessageBox>

fisaMedicala::fisaMedicala(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::fisaMedicala),textEdit(new QTextEdit(this)), backButton(new QPushButton("Back", this))
{
    ui->setupUi(this);

    QVBoxLayout *layout = new QVBoxLayout(this);
    layout->addWidget(textEdit);
    layout->addWidget(backButton);

    connect(backButton, &QPushButton::clicked, this, &fisaMedicala::goBack);
}

fisaMedicala::~fisaMedicala()
{
    delete ui;
}

void fisaMedicala::loadFile(const QString &filePath)
{
    QFile file(filePath);
    if (!file.open(QIODevice::ReadOnly | QIODevice::Text)) {
        QMessageBox::warning(this, tr("Error"), tr("Cannot open file %1:\n%2.")
                                                    .arg(filePath)
                                                    .arg(file.errorString()));
        return;
    }

    QTextStream in(&file);
    QString content = in.readAll();
    textEdit->setPlainText(content);
    textEdit->setReadOnly(true);
}

void fisaMedicala::goBack()
{
    // Ascunde fereastra actuală
    this->hide();
}
