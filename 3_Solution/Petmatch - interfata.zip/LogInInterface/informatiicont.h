#ifndef INFORMATIICONT_H
#define INFORMATIICONT_H

#include"actualizarecont.h"
#include <QDialog>

namespace Ui {
class informatiiCont;
}

class informatiiCont : public QDialog
{
    Q_OBJECT

public:
    explicit informatiiCont(QWidget *parent = nullptr);
    ~informatiiCont();

    void initializeWindow();
    QString getInformatii();

signals:
    void resultReady(const QString &result);

private:
    Ui::informatiiCont *ui;

    void actualizare(QString optiune);

private slots:
    void closeWindow();
    void handleResult(const QString &result);
    void updateField(const QString &optiune, const QString &newValue); // Adăugat slot nou
};

#endif // INFORMATIICONT_H
