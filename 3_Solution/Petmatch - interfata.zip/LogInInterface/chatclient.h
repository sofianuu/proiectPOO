#ifndef CHATCLIENT_H
#define CHATCLIENT_H

#include <QDialog>
#include <QWidget>
#include <QVBoxLayout>
#include<QLineEdit>
#include<QTextEdit>
#include<QVBoxLayout>

namespace Ui {
class chatClient;
}

class chatClient : public QDialog
{
    Q_OBJECT

public:
    explicit chatClient(QWidget *parent = nullptr);
    ~chatClient();

    void primesteMesaje();



private:
    Ui::chatClient *ui;

    QVBoxLayout *messagesLayout;
    QLineEdit *messageInput;
    QVBoxLayout *layout;
};

#endif // CHATCLIENT_H
