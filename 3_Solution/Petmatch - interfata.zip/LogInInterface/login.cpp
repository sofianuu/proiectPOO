#include "login.h"
#include "ui_login.h"
#include"inregistraresucces.h"
#include<QMessageBox>
#include<QPixmap>
#include<QString>
#include <unistd.h>
#include <QCryptographicHash>
#include"cadministrator.h"
#include"mainwindow.h"
#include<iostream>

LogIn::LogIn(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::LogIn)
{
    ui->setupUi(this);
    QPixmap pix("D:/Qt_bun/POO/LogInInterface/img.jpg");
    ui->labelpet1->setPixmap(pix.scaled(500,500,Qt::KeepAspectRatio));

    connect(ui->pushButton,SIGNAL(clicked(bool)),this,SLOT(button()));
    connect(ui->pushButton_2,SIGNAL(clicked()),this,SLOT(close()));

    ui->comboBox->addItem("Administrator");
    ui->comboBox->addItem("Client");
    tries=4;
}

LogIn::~LogIn()
{
    delete ui;
}

void LogIn::button()
{
    if(tries>0)
        {
            QString uName=ui->lineEdit->text();
            QString uCode=ui->lineEdit_2->text();

            QByteArray hashBytes = QCryptographicHash::hash(uCode.toUtf8(), QCryptographicHash::Sha256);
            QString hashedPassword = QString::fromLatin1(hashBytes.toHex());

            char answer[1024];

            if (ui->comboBox->currentIndex() == 0 && ui->comboBox->currentText() == "Administrator")
            {
                QString buff=QString("4")+"#"+uName+"#"+hashedPassword;
                const char* buffer=buff.toUtf8().constData();
                TCPClient::getInstance()->send(buffer,strlen(buffer));
                int recv_bytes=TCPClient::getInstance()->recv(answer,1024);
                answer[recv_bytes]='\0';
            } else if (ui->comboBox->currentIndex() == 1 && ui->comboBox->currentText() == "Client")
            {
                QString buff=QString("5")+"#"+uName+"#"+hashedPassword;
                const char* buffer=buff.toUtf8().constData();
                TCPClient::getInstance()->send(buffer,strlen(buffer));
                int recv_bytes=TCPClient::getInstance()->recv(answer,1024);
                answer[recv_bytes]='\0';
            }


            if(answer[0]=='1')
            {
                QMessageBox tmp;
                tmp.setFixedSize(2000, 2000);
                QMessageBox::information(this,"Welcome Message","User: "+uName+"\n""Autentificare reusita!");

                if (ui->comboBox->currentIndex() == 0 && ui->comboBox->currentText() == "Administrator")
                {
                    CAdministrator::getInstance2(uName,hashedPassword);
                    CAdministrator::getInstance()->setData(answer);
                }
                else
                {
                    CClient::getInstance()->setUsername(uName);
                    CClient::getInstance()->setPassword(hashedPassword);
                    CClient::getInstance()->setData((answer));
                }

                mainWindow::getInstance()->afisareWidget();
                this->hide();
            }
            else if(answer[0]=='0')
            {
                tries-=1;
                QString triesString = QString::number(tries);
                if(tries==0)
                {
                    QMessageBox::critical(this,"Ups! V-ati blocat!","Prea multe incercari!""\n""Incercati mai tarziu!");
                }
                else
                {
                    QMessageBox::information(this,"Username sau parola gresita!","      Incercati inca o data!     ""\n""      Mai aveti "+triesString+" incercari!          ");
                    ui->lineEdit->clear();
                    ui->lineEdit_2->clear();
                }
            }
            else if(answer[0]=='2')
            {
                QMessageBox::critical(this,"Eroare","Nu va puteti conecta ca administrator!");
                tries-=1;
            }
        }
}

