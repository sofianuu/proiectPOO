#include "actualizarecont.h"
#include "ui_actualizarecont.h"
#include"tcpclient.h"
#include<QMessageBox>
#include <QCryptographicHash>
#include<iostream>


actualizareCont::actualizareCont(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::actualizareCont)
{
    ui->setupUi(this);

    connect(ui->pushButton, &QPushButton::clicked, this, &actualizareCont::handleButtonClick);
}


actualizareCont::~actualizareCont()
{
    delete ui;
}

void actualizareCont::initializeWindow(QString buffer)
{
    ui->label_3->setText(buffer);
}

QString actualizareCont::setNewName()
{
    QString nume = ui->lineEditReset->text();
    emit updateData("nume", nume);
    return nume;
}

QString actualizareCont::setNewSurname()
{
    QString prenume = ui->lineEditReset->text();
    emit updateData("prenume", prenume);
    return prenume;
}

QString actualizareCont::setNewAdress()
{
    QString adresa = ui->lineEditReset->text();
    emit updateData("adresa", adresa);
    return adresa;

}

QString actualizareCont::setNewCellphone()
{
    QString telefon = ui->lineEditReset->text();
    emit updateData("nr tel", telefon);
    return telefon;
}

QString actualizareCont::setNewEmail()
{
    QString email = ui->lineEditReset->text();
    emit updateData("email", email);
    return email;
}

void actualizareCont::checkCharacter(QString buffer)
{
    for(int i=0;i<buffer.length();++i)
    {
        if(strchr("#",buffer[i].toLatin1())!=NULL)
        {
            QMessageBox::critical(this,"Eroare","Campul introdus contine caracterul '#'!""\n""Incercati din nou!");
            break;
        }
    }
}

bool actualizareCont::checkUsername(QString username)
{
    this->checkCharacter(username);

    qDebug()<<"Username: "<<username;

    QString buff=QString("2")+"#"+username;

    const char* bufferUsername=buff.toUtf8().constData();
    TCPClient::getInstance()->send(bufferUsername,strlen(bufferUsername));
    char answerUsername[1024];
    int recv_bytes=TCPClient::getInstance()->recv(answerUsername,1024);
    answerUsername[recv_bytes]='\0';

    if(strcmp(answerUsername,"0")==0)
    {
        QMessageBox::critical(this,"Eroare","Usernameul introdus este folosit deja!""\n""Incercati din nou!");
        return false;
    }
    return true;
}

QString actualizareCont::setNewUsername()
{
    QString username = ui->lineEditReset->text();
    emit updateData("username", username);
    return username;
}

bool actualizareCont::checkPassword(QString password)
{
    this->checkCharacter(password);

    bool hasUpperCase=false;
    bool hasDigit=false;

    for(int i=0;i<password.length();++i)
    {
        if(password.at(i).isUpper())
        {
            hasUpperCase=true;
        }
        else if(password.at(i).isDigit()){
            hasDigit=true;
        }
    }
    if(password.length()>=8 && password.length()<=20 && hasUpperCase && hasDigit)
    {
        return true;
    }
    else
    {
        QMessageBox::critical(this,"Eroare","Parola introdusa trebuie sa contina cel putin o litera mare, o cifra si minimum 8 caractere!""\n""Incercati din nou!");
        return false;
    }
}

QString actualizareCont::hashPassword(const QString& password)
{
    QByteArray hashBytes = QCryptographicHash::hash(password.toUtf8(), QCryptographicHash::Sha256);
    QString hashedPassword = QString::fromLatin1(hashBytes.toHex());

    return hashedPassword;
}

QString actualizareCont::setNewPassword()
{
    QString password = ui->lineEditReset->text();
    if (checkPassword(password)) {
        QString hashedPassword = hashPassword(password);
        emit updateData("parola", hashedPassword);
        return hashedPassword;
    }
    return "";
}

void actualizareCont::button()
{
    this->hide();
}

void actualizareCont::readOption()
{
    ui->lineEditReset->text();
}


void actualizareCont::handleButtonClick() {
    QString optiune = ui->label_3->text();
    bool updated = false;  // Flag to check if the update occurred

    if (optiune == "nume") {
        setNewName();
        updated = true;
    } else if (optiune == "prenume") {
        setNewSurname();
        updated = true;
    } else if (optiune == "adresa") {
        setNewAdress();
        updated = true;
    } else if (optiune == "email") {
        setNewEmail();
        updated = true;
    } else if (optiune == "parola") {
        setNewPassword();
        updated = true;
    } else if (optiune == "nr tel") {
        setNewCellphone();
        updated = true;
    } else if (optiune == "username") {
        setNewUsername();
        updated = true;
    }

    if (updated) {
        this->hide();
    }
}

