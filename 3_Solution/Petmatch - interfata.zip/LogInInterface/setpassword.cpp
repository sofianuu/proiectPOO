#include "setpassword.h"
#include "ui_setpassword.h"
#include "login.h"
#include"cclient.h"
#include<QMessageBox>
#include <QCryptographicHash>
#include <QDebug>
#include <QString>
#include <iostream>

SetPassword::SetPassword(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::SetPassword)
{
    ui->setupUi(this);
    QPixmap pix("D:/Qt_bun/POO/LogInInterface/password.jpg");
    ui->img->setPixmap(pix.scaled(300,300,Qt::KeepAspectRatio));

    connect(ui->pushButton,SIGNAL(clicked()),this,SLOT(finalizareInregistrare()));
}

SetPassword::~SetPassword()
{
    delete ui;
}

void SetPassword::setUsername()
{
    username=ui->lineEdit->text();
}

void SetPassword::setPassword1()
{
     password=ui->lineEdit_2->text();
}

void SetPassword::setPassword2()
{
    password2=ui->lineEdit_3->text();
}

bool SetPassword::checkUsername()
{
    this->setUsername();
    this->checkCharacter(username);

    qDebug()<<"Username: "<<username;

    QString buff=QString("2")+"#"+username;

    const char* bufferUsername=buff.toUtf8().constData();
    TCPClient::getInstance()->send(bufferUsername,strlen(bufferUsername));
    char answerUsername[1024];
    int recv_bytes=TCPClient::getInstance()->recv(answerUsername,1024);
    answerUsername[recv_bytes]='\0';

    if(strcmp(answerUsername,"0")==0)
    {
        QMessageBox::critical(this,"Eroare","Usernameul introdus este folosit deja!""\n""Incercati din nou!");
        return false;
    }
    return true;
}

void SetPassword::checkCharacter(QString buffer)
{
    for(int i=0;i<buffer.length();++i)
    {
        if(strchr("#",buffer[i].toLatin1())!=NULL)
        {
            QMessageBox::critical(this,"Eroare","Campul introdus contine caracterul '#'!""\n""Incercati din nou!");
            break;
        }
    }
}

bool SetPassword::checkPassword()
{
    this->setPassword1();
    this->setPassword2();

    qDebug()<<"Parola1: "<<password;
    qDebug()<<"Parola2: "<<password2;

    this->checkCharacter(password);

    bool hasUpperCase=false;
    bool hasDigit=false;

    for(int i=0;i<password.length();++i)
    {
        if(password.at(i).isUpper())
        {
            hasUpperCase=true;
        }
        else if(password.at(i).isDigit()){
            hasDigit=true;
        }
    }
    if(password.length()>=8 && password.length()<=20 && hasUpperCase && hasDigit)
    {
        if(password==password2)
        {
            QMessageBox::information(this,"Welcome Message","User: "+username+"\n""Inregistrare reusita!");
            return true;
        }
        else
        {
            QMessageBox::critical(this,"Eroare","Parola introdusa nu coincide cu prima!""\n""Incercati din nou!");
            return false;
        }
    }
    else
    {
        QMessageBox::critical(this,"Eroare","Parola introdusa trebuie sa contina cel putin o litera mare, o cifra si minimum 8 caractere!""\n""Incercati din nou!");
        return false;
    }
}


QString SetPassword::hashPassword(const QString& password)
{
    QByteArray hashBytes = QCryptographicHash::hash(password.toUtf8(), QCryptographicHash::Sha256);
    QString hashedPassword = QString::fromLatin1(hashBytes.toHex());

    return hashedPassword;
}

void SetPassword::finalizareInregistrare()
{
    if(this->checkUsername())
    {
        if(this->checkPassword()==0)
        {
            ui->lineEdit_2->clear();
            ui->lineEdit_3->clear();
        }
        else
        {
            QString hashedPassword=this->hashPassword(password);

            CClient::getInstance()->setUsername(username);
            CClient::getInstance()->setPassword(hashedPassword);
            CClient::getInstance()->afiseaza();

            QString buffer=QString("3")+"#"+username+"#"+hashedPassword;
            const char* buff=buffer.toUtf8().constData();
            TCPClient::getInstance()->send(buff,strlen(buff));
            char answer[1024];
            int recv_bytes=TCPClient::getInstance()->recv(answer,1024);
            answer[recv_bytes]='\0';

            CClient::destroyInstance();

            if(answer[0]='1')
            {
                this->hide();
                LogIn* log=new LogIn;
                log->show();
            }
            else if(answer[0]='0')
                {
                    QMessageBox::critical(this,"Eroare","Inregistrare esuata!""\n""Incercati din nou!");
                    CreeareCont cont;
                    cont.show();
                }
        }
    }
    else
    {
        ui->lineEdit->clear();
    }
}

QString SetPassword::setDataClient()
{
    CreeareCont cont;
    QString buffer=cont.getBufferClient();
    QString result=buffer+username+"#"+password;

    std::cout << "buffer: " << result.toStdString() << std::endl;

    return result;
}
