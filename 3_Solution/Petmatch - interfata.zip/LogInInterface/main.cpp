#include "login.h"
#include "welcome.h"
#include"mainwindow.h"

#pragma comment (lib, "Ws2_32.lib")
#define _CRT_SECURE_NO_WARNINGS
#include "TCPClient.h"
#include "Utils.h"
#include <cstdio>
#include<QDebug>
#include<iostream>

#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);

    TCPClient* connection=TCPClient::getInstance();
    sock_init();
    //connection->connect("172.16.44.15", 12345);   //wifi studenti
    //connection->connect("172.20.10.3", 12345);  //iphone gabi
    //connection->connect("192.168.0.100", 12345);  //acasa
    connection->connect("192.168.51.48", 12345);   //alexia
    char answer[1024];
    int recv_bytes=TCPClient::getInstance()->recv(answer,1024);
    answer[recv_bytes]='\0';

    std::cout<<answer<<std::endl;

    mainWindow::getInstance()->primesteDateAnimale();

    welcome w;
    w.show();
    return a.exec();
}

//filtru - cauta cum poti sa salvezi in string cuvantul ala
//actualizeaza profil
