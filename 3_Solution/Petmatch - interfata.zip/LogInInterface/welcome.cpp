#include "welcome.h"
#include "ui_welcome.h"
#include "login.h"
#include "creearecont.h"
#include"mainwindow.h"
#include<QPixmap>

welcome::welcome(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::welcome)
{
    ui->setupUi(this);
    QPixmap pix("D:/Qt_bun/POO/LogInInterface/1.jpg");
    ui->image_welcome->setPixmap(pix);
    connect(ui->pushButton_2,SIGNAL(clicked()),this,SLOT(buttonLogIn()));
    connect(ui->pushButton_3,SIGNAL(clicked()),this,SLOT(buttonCreateAccount()));
}

welcome::~welcome()
{
    delete ui;
}

void welcome::buttonLogIn()
{
    this->hide();
    LogIn* log=new LogIn;
    log->show();
}

void welcome::buttonCreateAccount()
{
    this->hide();
    CreeareCont* account=new CreeareCont;
    account->show();
}
void welcome::primesteInfAnimale()
{

}
