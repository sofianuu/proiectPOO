#ifndef LOGIN_H
#define LOGIN_H

#include <QMainWindow>
#include"tcpclient.h"


#pragma comment (lib, "Ws2_32.lib")
#define _CRT_SECURE_NO_WARNINGS
#include "TCPClient.h"
#include "Utils.h"
#include <cstdio>

QT_BEGIN_NAMESPACE
namespace Ui {
class LogIn;
}
QT_END_NAMESPACE

class LogIn : public QMainWindow
{
    Q_OBJECT

public:
    LogIn(QWidget *parent = nullptr);
    ~LogIn();

private slots:
    void button();

private:
    Ui::LogIn *ui;
    int tries;
    bool i;

};
#endif // LOGIN_H
