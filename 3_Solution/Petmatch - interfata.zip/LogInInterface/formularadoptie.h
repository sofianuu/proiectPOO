#ifndef FORMULARADOPTIE_H
#define FORMULARADOPTIE_H

#include <QDialog>
#include <QWidget>
#include <QLineEdit>
#include <QSpinBox>
#include <QComboBox>
#include <QCheckBox>
#include <QLabel>

namespace Ui {
class formularAdoptie;
}

class formularAdoptie : public QDialog
{
    Q_OBJECT

public:
    explicit formularAdoptie(QWidget *parent = nullptr);
    ~formularAdoptie();
    void setupWidgets();
    QString getSaveLocation();
    void setCaleFormular(QString cale);
    void sendFormular();

private slots:
    void saveFormData();

private:
    Ui::formularAdoptie *ui;

    QLineEdit *nameLineEdit;
    QSpinBox *ageSpinBox;
    QLineEdit *addressLineEdit;
    QComboBox *housingComboBox;
    QComboBox *financialComboBox;
    QCheckBox *experienceCheckBox;
    QComboBox *maritalComboBox;
    QCheckBox *childrenCheckBox;
    QLineEdit *animalLineEdit;
    QString caleFormular;
};

#endif // FORMULARADOPTIE_H
