#ifndef ACLIENT_H
#define ACLIENT_H
#include"iclient.h"

class AClient:public IClient
{
public:
    AClient(){};
    AClient(QString ufirstname,QString ulastname,QString uadress,QString uemail,QString ucellphone,QString usex,QString ubirthdate);
    AClient(QString uusername,QString upassword);

    void setData(QString buffer) override;
    int getId() override{return id;}
    QString getNume() override{return lastname;}
    QString getPrenume() override{return firstname;}
    QString getEmail() override{return email;}
    QString getAdresa() override{return adress;}
    QString getParola() override{return password;}
    QString getNrTel() override{return cellphone;}
    QString getUsername() override{return username;}
    QString getGen() override{return sex;}
    QString getDataNastere() override{return birthdate;}

protected:
    QString firstname;
    QString lastname;
    QString adress;
    QString email;
    QString cellphone;
    QString sex;
    QString birthdate;
    QString username;
    QString password;
    int id;
};

#endif // ACLIENT_H
