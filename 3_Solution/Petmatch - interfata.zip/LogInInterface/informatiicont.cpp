#include "informatiicont.h"
#include "ui_informatiicont.h"
#include"cadministrator.h"
//#include"actualizarecont.h"
#include"tcpclient.h"
#include<iostream>
#include<QMessageBox>

informatiiCont::informatiiCont(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::informatiiCont)
{
    ui->setupUi(this);
    connect(ui->pushButton, &QPushButton::clicked, this, [=]() {
        actualizare("nume");
    });
    connect(ui->pushButton_2, &QPushButton::clicked, this, [=]() {
        actualizare("prenume");
    });
    connect(ui->pushButton_3, &QPushButton::clicked, this, [=]() {
        actualizare("adresa");
    });
    connect(ui->pushButton_4, &QPushButton::clicked, this, [=]() {
        actualizare("email");
    });
    connect(ui->pushButton_5, &QPushButton::clicked, this, [=]() {
        actualizare("parola");
    });
    connect(ui->pushButton_6, &QPushButton::clicked, this, [=]() {
        actualizare("nr tel");
    });
    connect(ui->pushButton_7, &QPushButton::clicked, this, [=]() {
        actualizare("username");
    });

    connect(ui->pushButton_8,SIGNAL(clicked()),this,SLOT(closeWindow()));
    //connect(actualizareCont->getButonActualizare(), &QPushButton::clicked, this, &InformatiiCont::handleResult);

    //connect(ui->pushButton, &QPushButton::clicked, this, &MyWidget::handleButtonClick);
}

informatiiCont::~informatiiCont()
{
    delete ui;
}

void informatiiCont::initializeWindow()
{
    std::cout<<CClient::getInstance()->getId()<<std::endl;
    if(CAdministrator::getInstance()!=nullptr)
    {
        ui->label_9->setText(CAdministrator::getInstance()->getNume());
        ui->label_10->setText(CAdministrator::getInstance()->getPrenume());
        ui->label_11->setText(CAdministrator::getInstance()->getAdresa());
        ui->label_12->setText(CAdministrator::getInstance()->getEmail());
        ui->label_13->setText(CAdministrator::getInstance()->getParola());
        ui->label_14->setText(CAdministrator::getInstance()->getNrTel());
        ui->label_15->setText(CAdministrator::getInstance()->getUsername());
    }else
    {
        ui->label_9->setText(CClient::getInstance()->getNume());
        ui->label_10->setText(CClient::getInstance()->getPrenume());
        ui->label_11->setText(CClient::getInstance()->getAdresa());
        ui->label_12->setText(CClient::getInstance()->getEmail());
        ui->label_13->setText(CClient::getInstance()->getParola());
        ui->label_14->setText(CClient::getInstance()->getNrTel());
        ui->label_15->setText(CClient::getInstance()->getUsername());
    }
}


void informatiiCont::actualizare(QString buffer)
{
    actualizareCont* form = new actualizareCont();
    form->show();
    form->initializeWindow(buffer);

    connect(form, &actualizareCont::updateData, this, &informatiiCont::updateField);

}

void informatiiCont::closeWindow()
{
    this->hide();
}

void informatiiCont::handleResult(const QString &result)
{
    qDebug() << "Received result:" << result;

}


void informatiiCont::updateField(const QString &optiune, const QString &newValue)
{
    if (optiune == "nume") {
        ui->label_9->setText(newValue);
    } else if (optiune == "prenume") {
        ui->label_10->setText(newValue);
    } else if (optiune == "adresa") {
        ui->label_11->setText(newValue);
    } else if (optiune == "email") {
        ui->label_12->setText(newValue);
    } else if (optiune == "parola") {
        ui->label_13->setText(newValue);
    } else if (optiune == "nr tel") {
        ui->label_14->setText(newValue);
    } else if (optiune == "username") {
        ui->label_15->setText(newValue);
    }
    QString buffer = getInformatii();
    const char* buff = buffer.toUtf8().constData();
    TCPClient::getInstance()->send(buff, strlen(buff));
    char answer[1024];
    int recv_bytes = TCPClient::getInstance()->recv(answer, 1024);
    answer[recv_bytes] = '\0';
    if (answer[0] == '1')
    {
        qDebug() << "ai trimis informatiile actualizate";
    } else if(answer[0]=='0')
    {
        qDebug() << "nu ai trimis informatiile actualizate";
    }
    else if(answer[0]=='2'){
        qDebug() << "username existent";
        QMessageBox::critical(this,"Eroare","Usernameul introdus este folosit deja!""\n""Incercati din nou!");
    }
}

QString informatiiCont::getInformatii()
{
    QString lastname = ui->label_9->text();
    QString firstname = ui->label_10->text();
    QString adress = ui->label_11->text();
    QString email = ui->label_12->text();
    QString password = ui->label_13->text();
    QString cellphone = ui->label_14->text();
    QString username = ui->label_15->text();

    QString buffer = QString("6") + "#" + lastname + "#" + firstname + "#" + adress + "#" + email + "#" + password + "#" + cellphone + "#" + username;
    std::cout<<buffer.toStdString()<<std::endl;
    return buffer;
}

