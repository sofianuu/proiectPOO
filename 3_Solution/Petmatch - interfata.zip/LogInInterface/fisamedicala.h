#ifndef FISAMEDICALA_H
#define FISAMEDICALA_H

#include <QDialog>
#include <QWidget>
#include <QTextEdit>
#include <QPushButton>

namespace Ui {
class fisaMedicala;
}

class fisaMedicala : public QDialog
{
    Q_OBJECT

public:
    explicit fisaMedicala(QWidget *parent = nullptr);
    ~fisaMedicala();

    void loadFile(const QString &filePath);

public slots:
    void goBack();

private:
    Ui::fisaMedicala *ui;

    QTextEdit *textEdit;
    QPushButton *backButton;
};

#endif // FISAMEDICALA_H
