#ifndef INREGISTRARESUCCES_H
#define INREGISTRARESUCCES_H

#include <QDialog>
#include<QTimer>
#include <QObject>
#include <QDebug>

namespace Ui {
class InregistrareSucces;
}

class InregistrareSucces : public QDialog
{
    Q_OBJECT

public:
    explicit InregistrareSucces(QWidget *parent = nullptr);
    ~InregistrareSucces();

public slots:
     //void onTimerExpired();

private:
    Ui::InregistrareSucces *ui;
    QTimer* timer;
};

#endif // INREGISTRARESUCCES_H
