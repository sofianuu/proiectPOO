#include "adminlistmesagerie.h"
#include "ui_adminlistmesagerie.h"
#include"tcpclient.h"
#include<QVBoxLayout>
#include<iostream>
#include<QPushButton>
#include<QDebug>

adminListMesagerie::adminListMesagerie(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::adminListMesagerie)
{
    ui->setupUi(this);

    layout=new QVBoxLayout(this);
}

adminListMesagerie::~adminListMesagerie()
{
    delete ui;
}

void adminListMesagerie::primesteUsername()
{
    char answerNrUsername[1024];
    int recv_bytesNrUsername=TCPClient::getInstance()->recv(answerNrUsername,1024);
    answerNrUsername[recv_bytesNrUsername]='\0';

    char nrUsername[2];
    strcpy(nrUsername,answerNrUsername);
    int numar = atoi(nrUsername);
    QString buff="primit";

    const char* buffer=buff.toUtf8().constData();
    TCPClient::getInstance()->send(buffer,strlen(buffer));
    qDebug()<<"nr username: "<<numar;

    for(int i=0;i<numar;i++)
    {
        char answer[1024];
        int recv_bytes=0;
        recv_bytes=TCPClient::getInstance()->recv(answer,1024);
        if(recv_bytes==0)
        {
            QString buff="neprimit";
            const char* buffer=buff.toUtf8().constData();
            TCPClient::getInstance()->send(buffer,strlen(buffer));
        }
        else
        {
            QString buff="primit";
            const char* buffer=buff.toUtf8().constData();
            TCPClient::getInstance()->send(buffer,strlen(buffer));
        }
        answer[recv_bytes]='\0';

        std::cout<<"Buffer: "<<answer<<std::endl;

        QString username = QString::fromUtf8(answer);

        QPushButton *button = new QPushButton(username, this);
        layout->addWidget(button);
        connect(button, &QPushButton::clicked, [username]() {
            QString buff=QString("14")+"#"+username;
            const char* buffer=buff.toUtf8().constData();
            TCPClient::getInstance()->send(buffer,strlen(buffer));

            chatAdmin* chat=new chatAdmin(username);
            chat->show();
            chat->primesteMesaje();
        });


    }
}
