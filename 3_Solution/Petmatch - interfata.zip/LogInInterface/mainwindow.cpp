#include "mainwindow.h"
#include "ui_mainwindow.h"
#include"informatiicont.h"
#include"donare.h"
#include"afisaredetalii.h"
#include"adminwindow.h"
#include"addnewanimal.h"
#include"cadministrator.h"
#include"chatclient.h"
#include"adminListMesagerie.h"
#include"welcome.h"

mainWindow* mainWindow::instance=nullptr;

mainWindow::mainWindow(QWidget *parent) : QDialog(parent), ui(new Ui::mainWindow)
{
    ui->setupUi(this);
}

mainWindow::~mainWindow()
{
    delete ui;
}


mainWindow* mainWindow::getInstance(){
    if(!instance)
    {
        instance=new mainWindow();
    }
    return instance;
}

void mainWindow::destroyInstance(){
    if(instance)
    {
        delete instance;
        instance=nullptr;
    }
}

void mainWindow::adaugareImagine(QVBoxLayout* layout,QLabel* imageLabel, QPixmap image)
{
    if (!image.isNull()) {
        QPixmap scaledImage = image.scaled(200, 200, Qt::KeepAspectRatio);
        imageLabel->setPixmap(scaledImage);
    } else {
        imageLabel->setText("Imaginea nu poate fi încărcată");
    }
    layout->addWidget(imageLabel);
}

void mainWindow::afisareLeftLayout(QHBoxLayout* mainLayout)
{
    QFont fontButtons("Gabriola",25,QFont::Normal);

    QVBoxLayout* additionalLayout = new QVBoxLayout();

    QPushButton *cont = new QPushButton(" Informatii cont ");
    cont->setFont(fontButtons);
    cont->setFixedSize(300,50);
    cont->setStyleSheet("background-color: 	#2f3b2e;color: white;");
    additionalLayout->addWidget(cont);

    QPushButton *donare = new QPushButton(" Doneaza! ");
    donare->setFont(fontButtons);
    donare->setFixedSize(300,50);
    donare->setStyleSheet("background-color: 	#2f3b2e;color: white;");
    additionalLayout->addWidget(donare);

    QPushButton *contact = new QPushButton(" Contacteaza-ne! ");
    contact->setFont(fontButtons);
    contact->setFixedSize(300,50);
    contact->setStyleSheet("background-color: 	#2f3b2e;color: white;");
    additionalLayout->addWidget(contact);

    QPushButton *chatAdmin = new QPushButton(" Mesagerie ");
    chatAdmin->setFont(fontButtons);
    chatAdmin->setFixedSize(300,50);
    chatAdmin->setStyleSheet("background-color: #2f3b2e; color: white;");
    additionalLayout->addWidget(chatAdmin);

    QPushButton *deconectare = new QPushButton(" Deconectare ");
    deconectare->setFont(fontButtons);
    deconectare->setFixedSize(300,50);
    deconectare->setStyleSheet("background-color: 	#2f3b2e;color: white;");
    additionalLayout->addWidget(deconectare);

    QPushButton *adminButton = new QPushButton(" Administrare Formulare ");
    adminButton->setFont(fontButtons);
    adminButton->setFixedSize(300,50);
    adminButton->setStyleSheet("background-color: 	#2f3b2e;color: white;");
    additionalLayout->addWidget(adminButton);

    QPushButton *adaugaAnimal = new QPushButton(" Adaugă Animal ");
    adaugaAnimal->setFont(fontButtons);
    adaugaAnimal->setFixedSize(300,50);
    adaugaAnimal->setStyleSheet("background-color: #2f3b2e; color: white;");
    additionalLayout->addWidget(adaugaAnimal);


    connect(adaugaAnimal, &QPushButton::clicked, this, &mainWindow::adaugaAnimalPressed);
    connect(chatAdmin,&QPushButton::clicked, this, &mainWindow::chatAdminPressed);


    if(CClient::getInstance()->getId()==1)
    {
        adminButton->setVisible(false);
        adaugaAnimal->setVisible(false);
        chatAdmin->setVisible(false);
    }
    else
    {
        contact->setVisible(false);
    }


    connect(cont, &QPushButton::clicked, this, &mainWindow::contPressed);
    connect(donare, &QPushButton::clicked, this, &mainWindow::donarePressed);
    connect(contact, &QPushButton::clicked, this, &mainWindow::contactPressed);
    connect(deconectare, &QPushButton::clicked, this, &mainWindow::deconectarePressed);
    QObject::connect(adminButton, &QPushButton::clicked, []() {
        AdminWindow *adminWindow = new AdminWindow();
        adminWindow->show();
    });

    mainLayout->addLayout(additionalLayout);
}

Animal mainWindow::setAnimal(QString buffer)
{
    QString nume;
    QString rasa;
    QString descriere;
    QString dataNastere;
    QString stareSterilizare;
    QString dataSterilizare;
    QString dataInregistrare;
    QString fisaMedicala;
    QString imagine;
    QString status;
    QString descriereAmanuntita;

    QByteArray byteArray = buffer.toUtf8();
    const char *cStr = byteArray.constData();

    char *cStrCopy = strdup(cStr);

    char *token = strtok(cStrCopy, "#");
    if (token != nullptr)
    {
        nume = token;
        rasa = strtok(nullptr, "#");
        descriere = strtok(nullptr, "#");
        dataNastere = strtok(nullptr, "#");
        stareSterilizare = strtok(nullptr, "#");
        dataSterilizare = strtok(nullptr, "#");
        dataInregistrare = strtok(nullptr, "#");
        fisaMedicala = strtok(nullptr, "#");
        imagine = strtok(nullptr, "#");
        status = strtok(nullptr, "#");
        descriereAmanuntita = strtok(nullptr, "#");
    }
    Animal animal(nume,rasa,descriere,dataNastere,stareSterilizare,dataSterilizare, dataInregistrare,fisaMedicala,imagine,status,descriereAmanuntita);

    return animal;
}

void mainWindow::primesteDateAnimale()
{

    char answerNrAnimals[1024];
    int recv_bytesNrAnimals=TCPClient::getInstance()->recv(answerNrAnimals,1024);
    answerNrAnimals[recv_bytesNrAnimals]='\0';

    char nrAnimals[2];
    strcpy(nrAnimals,answerNrAnimals);
    int numar = atoi(nrAnimals);
    QString buff="primit";
    const char* buffer=buff.toUtf8().constData();
    TCPClient::getInstance()->send(buffer,strlen(buffer));

    std::cout<<"nr:  "<<numar<<std::endl;

    for(int i=0;i<numar;i++)
    {
        char answer[1024];
        int recv_bytes=0;
        recv_bytes=TCPClient::getInstance()->recv(answer,1024);
        std::cout<<"nr bytes animal: "<<recv_bytesNrAnimals<<std::endl;
        if(recv_bytes==0)
        {
            QString buff="neprimit";
            const char* buffer=buff.toUtf8().constData();
            TCPClient::getInstance()->send(buffer,strlen(buffer));
        }
        else
        {
            QString buff="primit";
            const char* buffer=buff.toUtf8().constData();
            TCPClient::getInstance()->send(buffer,strlen(buffer));
        }

        answer[recv_bytes]='\0';

        std::cout<<"buffer: "<<answer<<std::endl;

        animale.push_back(setAnimal(answer));

        answer[0]='\0';
    }
    std::cout<<"ai terminat functia"<<std::endl;
}

void mainWindow::applyFilter(const QString& text)
{
    for (int i = 0; i < layoutList.size(); ++i)
    {
        QHBoxLayout* layout = layoutList[i];
        QWidget* widget = widgetList[i];

        bool found = false;
        for (int j = 0; j < layout->count(); ++j)
        {
            QLayoutItem* item = layout->itemAt(j);
            QWidget* widgetItem = item->widget();

            QLabel* breedLabel = qobject_cast<QLabel*>(widgetItem);
            if (breedLabel && breedLabel->text().contains(text, Qt::CaseInsensitive))
            {
                found = true;
                break;
            }
        }

        widget->setVisible(found);
    }
}


void mainWindow::afisareWidget()
{

    QFont font("Gabriola",15,QFont::Normal);

    QWidget* widget=new QWidget();

    QHBoxLayout* mainLayout = new QHBoxLayout(widget);
    widget->setLayout(mainLayout);
    QScreen* screen = QGuiApplication::primaryScreen();
    QRect screenSize = screen->availableGeometry();
    widget->setFixedSize(screenSize.width(), screenSize.height());
    widget->setStyleSheet("background-color: rgb(228, 244, 205);");

    QVBoxLayout* scrollAreaLayout=new QVBoxLayout();
    QScrollArea* scrollArea = new QScrollArea();
    scrollArea->setWidgetResizable(true);
    QWidget* scrollWidget = new QWidget();
    QVBoxLayout* scrollLayout = new QVBoxLayout(scrollWidget);

    QLineEdit* filterLineEdit = new QLineEdit();
    filterLineEdit->setPlaceholderText("Filtru...");
    scrollLayout->addWidget(filterLineEdit);

    scrollAreaLayout->addWidget(scrollArea);
    mainLayout->addLayout(scrollAreaLayout);

    this->afisareLeftLayout(mainLayout);

    for(const auto& animal : animale)
    {
        QHBoxLayout* layout=new QHBoxLayout(widget);

        QVBoxLayout* leftLayout = new QVBoxLayout();
        QLabel* imageLabel = new QLabel();
        QPixmap image(animal.getImagine());
        adaugareImagine(leftLayout,imageLabel,image);

        QVBoxLayout* rightLayout = new QVBoxLayout();
        QLabel* nameLabel = new QLabel("Nume: " + animal.getNume());
        QLabel* breedLabel = new QLabel("Rasa: " + animal.getRasa());
        QLabel* birthDateLabel = new QLabel("Data Nastere: " + animal.getDataNastere());
        QLabel* descriptionLabel = new QLabel("Descriere: " + animal.getDescriere());
        QLabel* statusLabel = new QLabel("Status: " + animal.getStatus());
        nameLabel->setFont(font);
        breedLabel->setFont(font);
        birthDateLabel->setFont(font);
        descriptionLabel->setFont(font);
        statusLabel->setFont(font);
        rightLayout->addWidget(nameLabel);
        rightLayout->addWidget(breedLabel);
        rightLayout->addWidget(birthDateLabel);
        rightLayout->addWidget(descriptionLabel);
        rightLayout->addWidget(statusLabel);

        layout->addLayout(leftLayout);
        layout->addLayout(rightLayout);
        layout->setSpacing(10);

        QPushButton *AfisDetalii = new QPushButton(" Apasa aici pentru mai multe detalii! ");

        connect(AfisDetalii, &QPushButton::clicked, this, [this, animal]() {
            afisDetalii(animal);
        });

        AfisDetalii->setFont(font);
        AfisDetalii->setFixedSize(300,25);
        AfisDetalii->setStyleSheet("background-color: 	#2f3b2e;color: white;");
        layout->addWidget(AfisDetalii);


        scrollLayout->addLayout(layout);
        scrollLayout->addWidget(AfisDetalii);


        mainLayout->addLayout(layout);

    }

    scrollArea->setWidget(scrollWidget);
    mainLayout->addWidget(scrollArea);

    widget->adjustSize();

    //connect(filterLineEdit, &QLineEdit::textChanged, this, &mainWindow::applyFilter);



    widget->show();
}

void mainWindow::contPressed()
{
    this->hide();
    informatiiCont* cont=new informatiiCont;
    cont->initializeWindow();

    cont->show();
}

void mainWindow::donarePressed()
{
    this->hide();
    donare* donation=new donare;
    donation->show();

}

void mainWindow::contactPressed()
{
    QString buff=QString("12");
    const char* buffer=buff.toUtf8().constData();
    TCPClient::getInstance()->send(buffer,strlen(buffer));

    chatClient *client = new chatClient(this);
    client->show();
    client->primesteMesaje();
}

void mainWindow::chatAdminPressed()
{
    QString buff=QString("13");
    const char* buffer=buff.toUtf8().constData();
    TCPClient::getInstance()->send(buffer,strlen(buffer));

    adminListMesagerie* admin=new adminListMesagerie(this);
    admin->show();
    admin->primesteUsername();
}

void mainWindow::deconectarePressed()
{
    //TCPClient::getInstance()->closeConnection();
    std::cout<<"Deconectare reusita!"<<std::endl;

    char answer[1024];
    QString buff=QString("15");
    const char* buffer=buff.toUtf8().constData();
    TCPClient::getInstance()->send(buffer,strlen(buffer));
    int recv_bytes=TCPClient::getInstance()->recv(answer,1024);
    answer[recv_bytes]='\0';

    if(CClient::getInstance()->getId()==1)
        CClient::destroyInstance();
    else
        CAdministrator::destroyInstance();

    this->close();
    welcome* w=new welcome(this);
    w->show();


}


void mainWindow::afisDetalii(const Animal &animal)
{
    afisareDetalii* detalii=new afisareDetalii;
    detalii->initializeWidget(animal);

    this->hide();
    detalii->show();
}

void mainWindow::adaugaAnimalPressed()
{
    AddNewAnimal *newAnimal = new AddNewAnimal(this);
    newAnimal->exec();
}
