#ifndef CCLIENT_H
#define CCLIENT_H
#include"aclient.h"

class CClient:public AClient
{
protected:
    static CClient* instance;
    CClient():AClient(){}
    CClient(const CClient& cop){this->instance=cop.instance;}
    virtual ~ CClient(){}
    CClient(QString ufirstname,QString ulastname,QString uadress,QString uemail,QString ucellphone,QString usex,QString ubirthdate):AClient(ufirstname,ulastname,uadress,uemail,ucellphone,usex,ubirthdate){}
    CClient(QString uusername,QString upassword):AClient(uusername,upassword){}

public:
    static CClient* getInstance();
    static void destroyInstance();
    static CClient* getInstance7(QString ufirstname,QString ulastname,QString uadress,QString uemail,QString ucellphone,QString usex,QString ubirthdate);
    static CClient* getInstance2(QString uusername,QString upassword);
    void afiseaza();
    void setId() override;
    void setUsername(QString buffer) override;
    void setPassword(QString buffer) override;

};

#endif // CCLIENT_H
