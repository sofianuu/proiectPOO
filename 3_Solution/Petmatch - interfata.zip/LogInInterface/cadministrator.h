#ifndef CADMINISTRATOR_H
#define CADMINISTRATOR_H
#include "cclient.h"

class CAdministrator:public CClient
{
private:
    static CAdministrator* instance;
    CAdministrator():CClient(){}
    CAdministrator(const CAdministrator& cop){this->instance=cop.instance;}
    CAdministrator(QString uusername,QString upassword):CClient(uusername,upassword){}
    ~ CAdministrator(){}
    CAdministrator(QString ufirstname,QString ulastname,QString uadress,QString uemail,QString ucellphone,QString usex,QString ubirthdate):CClient(ufirstname,ulastname,uadress,uemail,ucellphone,usex,ubirthdate){}
public:
    static CAdministrator* getInstance();
    static void destroyInstance();
    static CAdministrator* getInstance2(QString uusername,QString upassword);

    void setId();

};

#endif // CADMINISTRATOR_H
