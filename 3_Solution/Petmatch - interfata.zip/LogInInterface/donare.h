#ifndef DONARE_H
#define DONARE_H

#include <QDialog>
#include<iostream>

namespace Ui {
class donare;
}

class donare : public QDialog
{
    Q_OBJECT

public:
    explicit donare(QWidget *parent = nullptr);
    ~donare();
    QString getBuffer();

private slots:
    void trimiteDonare();

private:
    Ui::donare *ui;

    QString suma;
};

#endif // DONARE_H
