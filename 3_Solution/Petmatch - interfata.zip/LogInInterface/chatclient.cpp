#include "chatclient.h"
#include "ui_chatclient.h"
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QLineEdit>
#include <QPushButton>
#include <QLabel>
#include <QScrollArea>
#include <QScrollBar>
#include"tcpclient.h"
#include<iostream>
#include <cstring>
#include <cstdlib>
#include <QString>
#include<QDebug>

chatClient::chatClient(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::chatClient)
{
    ui->setupUi(this);

    layout = new QVBoxLayout(this);

    QHBoxLayout *inputLayout = new QHBoxLayout();
    QLineEdit *messageInput = new QLineEdit(this);
    QPushButton *sendButton = new QPushButton("Trimite", this);

    inputLayout->addWidget(messageInput);
    inputLayout->addWidget(sendButton);
    layout->addLayout(inputLayout);

    // Conectare semnal pentru trimiterea mesajului
    connect(sendButton, &QPushButton::clicked, this, [=]() {
        QString newMessage = messageInput->text();
        if (!newMessage.isEmpty()) {

            QString buff=QString("10")+"#"+newMessage;
            const char* buffer=buff.toUtf8().constData();
            TCPClient::getInstance()->send(buffer,strlen(buffer));

            // Afișează mesajul
            QLabel *newLabel = new QLabel(newMessage);
            newLabel->setAlignment(Qt::AlignRight);
            layout->addWidget(newLabel);

            messageInput->clear();
        }
    });

}

void chatClient::primesteMesaje()
{

    char answerNrMesaje[1024];
    int recv_bytesNrMesaje=TCPClient::getInstance()->recv(answerNrMesaje,1024);
    answerNrMesaje[recv_bytesNrMesaje]='\0';

    char nrMesaje[2];
    strcpy(nrMesaje,answerNrMesaje);
    int numar = atoi(nrMesaje);
    QString buff="primit";

    const char* buffer=buff.toUtf8().constData();
    TCPClient::getInstance()->send(buffer,strlen(buffer));

    for(int i=0;i<numar;i++)
    {
        char answer[1024];
        int recv_bytes=0;
        recv_bytes=TCPClient::getInstance()->recv(answer,1024);
        if(recv_bytes==0)
        {
            QString buff="neprimit";
            const char* buffer=buff.toUtf8().constData();
            TCPClient::getInstance()->send(buffer,strlen(buffer));
        }
        else
        {
            QString buff="primit";
            const char* buffer=buff.toUtf8().constData();
            TCPClient::getInstance()->send(buffer,strlen(buffer));
        }

        answer[recv_bytes]='\0';

        std::cout<<"Buffer: "<<answer<<std::endl;

        QString string = QString::fromUtf8(answer);

        int delimiterIndex = string.indexOf('#');

        // Extrage ID-ul ca un șir de caractere
        QString idStr = string.left(delimiterIndex);

        // Convertă ID-ul la un întreg
        int id = idStr.toInt();

        // Extrage mesajul ca un șir de caractere
        QString message = string.mid(delimiterIndex + 1);

        // Afisează rezultatul
        qDebug() << "ID:" << id;
        qDebug() << "Mesaj:" << message;

        QLabel *label = new QLabel(message);
        if (id == 1) {
            label->setAlignment(Qt::AlignLeft);
        } else {
            label->setAlignment(Qt::AlignRight);
        }
        layout->addWidget(label);
    }
    show();
}

chatClient::~chatClient()
{
    delete ui;
}
