#ifndef AFISAREDETALII_H
#define AFISAREDETALII_H

#include <QDialog>
#include"animal.h"
#include"fisamedicala.h"
#include"formularadoptie.h"

namespace Ui {
class afisareDetalii;
}

class afisareDetalii : public QDialog
{
    Q_OBJECT

public:
    explicit afisareDetalii(QWidget *parent = nullptr);
    ~afisareDetalii();

    void initializeWidget(const Animal &animal);

private slots:
    void backButtonWindow();
    void showMedicalRecord();
    void setFisaMedicala(QString fmedicala);
    void loadFile(const QString &fileName);
    void createFormularAdoptie();
    void on_StatusButton_clicked();

private:
    Ui::afisareDetalii *ui;
    fisaMedicala *medicalRecordWindow;
    formularAdoptie* formular;

    void loadImage(const QString &filePath);

    QString fMedicala;
    Animal animalCurrent;
};

#endif // AFISAREDETALII_H
