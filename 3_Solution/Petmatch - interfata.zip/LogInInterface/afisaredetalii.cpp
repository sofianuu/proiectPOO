#include "afisaredetalii.h"
#include "ui_afisaredetalii.h"
#include<QWidget>
#include<QHBoxLayout>
#include<QLabel>
#include<QPixmap>
#include<QHBoxLayout>
#include<QPushButton>
#include<QObject>
#include"mainwindow.h"
#include"animal.h"
#include"fisamedicala.h"
#include"formularadoptie.h"
#include<iostream>
#include"formstatusdialog.h"

afisareDetalii::afisareDetalii(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::afisareDetalii)
{
    ui->setupUi(this);
    connect(ui->backButton, SIGNAL(clicked()), this, SLOT(backButtonWindow()));
    connect(ui->medicalRecordButton, &QPushButton::clicked, this, &afisareDetalii::showMedicalRecord);
    connect(ui->fAdoptie, SIGNAL(clicked()), this, SLOT(createFormularAdoptie()));
}

afisareDetalii::~afisareDetalii()
{
    delete ui;
}

void afisareDetalii::setFisaMedicala(QString fmedicala)
{
    this->fMedicala=fmedicala;
}

void afisareDetalii::loadFile(const QString &fileName)
{
    QFile file(fileName);
    if (!file.open(QIODevice::ReadOnly | QIODevice::Text)) {
        QMessageBox::warning(this, tr("Error"), tr("Cannot open file %1:\n%2.")
                                                    .arg(fileName)
                                                    .arg(file.errorString()));
        return;
    }

    QTextStream in(&file);
    QString content = in.readAll();
    ui->textEdit->setPlainText(content);
}

void afisareDetalii::loadImage(const QString &filePath)
{
    QPixmap pixmap(filePath);
    if (!pixmap.isNull()) {
        ui->label->setPixmap(pixmap);
        ui->label->setScaledContents(true); // Setează QLabel să redimensioneze imaginea pentru a se potrivi
    } else {
        // Tratează eroarea dacă imaginea nu se poate încărca
        ui->label->setText("Imaginea nu a putut fi încărcată.");
    }
}

void afisareDetalii::initializeWidget(const Animal &animal)
{
    animalCurrent=animal;
    setFisaMedicala(animal.getFisaMedicala());
    loadImage(animal.getImagine());
    ui->Nume->setText(animal.getNume());
    ui->label_1->setText(animal.getDataNastere());
    ui->label_2->setText(animal.getRasa());
    ui->label_4->setText(animal.getStareSterilizare());
    QString fileName=animal.getDescriereAmanuntita();
    loadFile(fileName);

    QObject::connect(ui->StatusButton, &QPushButton::clicked, []() {
        FormStatusDialog *statusDialog = new FormStatusDialog();
        statusDialog->exec();
    });
}

void afisareDetalii::backButtonWindow()
{
    this->hide();
}

void afisareDetalii::showMedicalRecord()
{
    if (!medicalRecordWindow) {
        medicalRecordWindow = new fisaMedicala(this);
    }

    if (!fMedicala.isEmpty()) {
        medicalRecordWindow->loadFile(fMedicala);
        medicalRecordWindow->show();
    }
}


void afisareDetalii::createFormularAdoptie()
{
    formular=new formularAdoptie;
    if(animalCurrent.getStatus().compare("Disponibil")!=0)
        QMessageBox::critical(this,"Ups!","Animalul nu este disponibil!""\n""Cautati alt animal!");
    formular->show();
}



void afisareDetalii::on_StatusButton_clicked()
{

}

