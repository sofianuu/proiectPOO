#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include<QLabel>
#include<QPixmap>
#include<QHBoxLayout>
#include<QPushButton>
#include<QtWidgets>
#include<QObject>
#include"animal.h"
#include<iostream>
#include"tcpclient.h"
#include"cclient.h"

namespace Ui {
class mainWindow;
}

class mainWindow : public QDialog
{
        Q_OBJECT
private:
    std::vector<Animal> animale;

    static mainWindow* instance;

    mainWindow(QWidget* parent=nullptr);
    ~mainWindow();

    //mainWindow(const mainWindow& cop){this->instance=cop.instance;}
    //~ mainWindow() {}
    //mainWindow(){}

public:
    static mainWindow* getInstance();
    static void destroyInstance();

    void afisareWidget();
    void adaugareImagine(QVBoxLayout* layout,QLabel* label, QPixmap image);
    void afisareLeftLayout(QHBoxLayout* mainLayout);
    Animal setAnimal(QString buffer);
    void primesteDateAnimale();
    void applyFilter(const QString& text);
    void contPressed();
    void donarePressed();
    void contactPressed();
    void deconectarePressed();
    void afisDetalii(const Animal &animal);
    void adaugaAnimalPressed();
    void chatAdminPressed();


private :
    Ui::mainWindow *ui;

    QVector<QHBoxLayout*> layoutList;
    QVector<QWidget*> widgetList;


};

#endif // MAINWINDOW_H
