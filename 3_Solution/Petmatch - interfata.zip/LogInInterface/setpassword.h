#ifndef SETPASSWORD_H
#define SETPASSWORD_H

#include <QDialog>
#include"tcpclient.h"
#include"creearecont.h"

namespace Ui {
class SetPassword;
}

class SetPassword : public QDialog
{
    Q_OBJECT

public:
    explicit SetPassword(QWidget *parent = nullptr);
    ~SetPassword();

private slots:
    void finalizareInregistrare();

private:
    QString username;
    QString password;
    QString password2;
    friend class CreeareCont;

    Ui::SetPassword *ui;
    bool checkUsername();
    bool checkPassword();
    QString hashPassword(const QString& password);
    void setUsername();
    void setPassword1();
    void setPassword2();
    void checkCharacter(QString buffer);
    QString setDataClient();

};

#endif // SETPASSWORD_H
