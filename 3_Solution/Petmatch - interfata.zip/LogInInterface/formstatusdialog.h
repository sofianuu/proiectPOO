#ifndef FORMSTATUSDIALOG_H
#define FORMSTATUSDIALOG_H

#include <QDialog>
#include <QLineEdit>
#include <QPushButton>
#include <QLabel>

namespace Ui {
class FormStatusDialog;
}

class FormStatusDialog : public QDialog
{
    Q_OBJECT

public:
    explicit FormStatusDialog(QWidget *parent = nullptr);
    ~FormStatusDialog();

private slots:
    void checkFormStatus();

private:
    Ui::FormStatusDialog *ui;

    QLineEdit *nameLineEdit;
    QLabel *statusLabel;

    QString getFormStatus(const QString &username);
};

#endif // FORMSTATUSDIALOG_H
