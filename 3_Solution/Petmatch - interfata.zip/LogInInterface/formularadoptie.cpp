#include "formularadoptie.h"
#include "ui_formularadoptie.h"
#include <QVBoxLayout>
#include <QPushButton>
#include <QFileDialog>
#include <QTextStream>
#include <QDebug>
#include<QMessageBox>
#include<QLineEdit>
#include"tcpclient.h"
#include<iostream>
#include<QFormLayout>

formularAdoptie::formularAdoptie(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::formularAdoptie)
{
    ui->setupUi(this);

    setupWidgets();
}

void formularAdoptie::setupWidgets() {
    QVBoxLayout *layout = new QVBoxLayout(this);
    QFormLayout *formLayout = new QFormLayout();

    nameLineEdit = new QLineEdit(this);
    ageSpinBox = new QSpinBox(this);
    addressLineEdit = new QLineEdit(this);
    housingComboBox = new QComboBox(this);
    financialComboBox = new QComboBox(this);
    experienceCheckBox = new QCheckBox("Experiență anterioară cu animale de companie", this);
    maritalComboBox = new QComboBox(this);
    childrenCheckBox = new QCheckBox("Copii", this);
    animalLineEdit = new QLineEdit(this);

    housingComboBox->addItems({"Casă", "Apartament"});
    financialComboBox->addItems({"Slabe", "Decente", "Bune", "Foarte bune", "Excepționale"});
    maritalComboBox->addItems({"Necăsătorit/ă", "Căsătorit/ă", "Divorțat/ă", "Văduv/ă"});

    formLayout->addRow("Nume și prenume:", nameLineEdit);
    formLayout->addRow("Vârstă:", ageSpinBox);
    formLayout->addRow("Adresă:", addressLineEdit);
    formLayout->addRow("Tip locuință:", housingComboBox);
    formLayout->addRow("Resurse financiare:", financialComboBox);
    formLayout->addRow("Experiență anterioară cu animale de companie:", experienceCheckBox);
    formLayout->addRow("Stare civilă:", maritalComboBox);
    formLayout->addRow("Copii:", childrenCheckBox);
    formLayout->addRow("Nume animal:", animalLineEdit);

    QPushButton *saveButton = new QPushButton("Salvează", this);
    connect(saveButton, &QPushButton::clicked, this, &formularAdoptie::saveFormData);

    layout->addWidget(new QLabel("Nume și prenume:", this));
    layout->addWidget(nameLineEdit);
    layout->addWidget(new QLabel("Vârstă:", this));
    layout->addWidget(ageSpinBox);
    layout->addWidget(new QLabel("Adresă:", this));
    layout->addWidget(addressLineEdit);
    layout->addWidget(new QLabel("Tip locuință:", this));
    layout->addWidget(housingComboBox);
    layout->addWidget(new QLabel("Resurse financiare:", this));
    layout->addWidget(financialComboBox);
    layout->addWidget(experienceCheckBox);
    layout->addWidget(maritalComboBox);
    layout->addWidget(childrenCheckBox);
    layout->addWidget(animalLineEdit);
    layout->addWidget(saveButton);


    setLayout(layout);
}

formularAdoptie::~formularAdoptie()
{
    delete ui;
}

void formularAdoptie::setCaleFormular(QString cale)
{
    caleFormular=cale;
}

void formularAdoptie::sendFormular()
{
    QString buff=QString("9")+"#"+animalLineEdit->text()+"#"+caleFormular;
    std::cout<<buff.toStdString()<<std::endl;
    const char* buffer=buff.toUtf8().constData();
    TCPClient::getInstance()->send(buffer,strlen(buffer));
    char answer[1024];
    int recv_bytes=TCPClient::getInstance()->recv(answer,1024);
    answer[recv_bytes]='\0';
    if(answer[0]='1')
    {
        QMessageBox::information(this,"Formular Adoptie","Formularul a fost trimis cu succes!");
    }
    else if(answer[0]='0')
    {
        QMessageBox::information(this,"Formular Adoptie","Formularul nu a fost trimis!");
    }
}

void formularAdoptie::saveFormData() {
    QString animal = animalLineEdit->text();
    QString directory = "D:/Qt_bun/POO/LogInInterface/formulareAdoptie";
    if (!directory.isEmpty()) {
        QString filename = directory + "/" + animal + ".txt";
            this->setCaleFormular(filename);
        QFile file(filename);

        if (file.open(QIODevice::WriteOnly | QIODevice::Text)) {
            QTextStream out(&file);
            out << "Nume și prenume: " << nameLineEdit->text() << "\n";
            out << "Vârstă: " << ageSpinBox->value() << "\n";
            out << "Adresă: " << addressLineEdit->text() << "\n";
            out << "Tip locuință: " << housingComboBox->currentText() << "\n";
            out << "Resurse financiare: " << financialComboBox->currentText() << "\n";
            out << "Experiență anterioară cu animale de companie: " << (experienceCheckBox->isChecked() ? "Da" : "Nu") << "\n";
            out << "Stare civilă: " << maritalComboBox->currentText() << "\n";
            out << "Copii: " << (childrenCheckBox->isChecked() ? "Da" : "Nu") << "\n";
            out << "Nume animal: " << animalLineEdit->text() << "\n";
            out << "Stare formular: În așteptare" << "\n";
            file.close();
            qDebug() << "Formularul a fost salvat cu succes în " << filename;
            close();
        } else {
            qDebug() << "Eroare la salvarea formularului!";
        }
    } else {
        qDebug() << "Nu s-a selectat niciun director de salvare.";
    }
    this->sendFormular();
}

QString formularAdoptie::getSaveLocation() {
    return caleFormular;
}
