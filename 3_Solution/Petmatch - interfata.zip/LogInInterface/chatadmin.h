#ifndef CHATADMIN_H
#define CHATADMIN_H

#include <QDialog>
#include <QWidget>
#include <QVBoxLayout>
#include<QLineEdit>
#include<QTextEdit>
#include<QVBoxLayout>

namespace Ui {
class chatAdmin;
}

class chatAdmin : public QDialog
{
    Q_OBJECT

public:
    explicit chatAdmin(const QString &username,QWidget *parent = nullptr);
    ~chatAdmin();

    void primesteMesaje();

private:
    Ui::chatAdmin *ui;

    QVBoxLayout *messagesLayout;
    QLineEdit *messageInput;
    QVBoxLayout *layout;
    QString username;
};

#endif // CHATADMIN_H
