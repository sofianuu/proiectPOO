#ifndef ICLIENT_H
#define ICLIENT_H
#include<QString>

class IClient
{
public:
    virtual void setData(QString buffer)=0;
    virtual void setId()=0;
    virtual void setUsername(QString buffer)=0;
    virtual void setPassword(QString buffer)=0;
    virtual int getId()=0;
    virtual QString getNume()=0;
    virtual QString getPrenume()=0;
    virtual QString getEmail()=0;
    virtual QString getAdresa()=0;
    virtual QString getParola()=0;
    virtual QString getNrTel()=0;
    virtual QString getUsername()=0;
    virtual QString getGen()=0;
    virtual QString getDataNastere()=0;
};

#endif // ICLIENT_H
